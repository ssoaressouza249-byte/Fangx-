package com.raylan.fangx.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.raylan.fangx.data.CommandRepository
import com.raylan.fangx.engine.DeviceCompatibilityScanner
import com.raylan.fangx.engine.ShizukuCommandExecutor
import com.raylan.fangx.model.CrosshairColorOption
import com.raylan.fangx.model.CrosshairConfig
import com.raylan.fangx.model.CrosshairShape
import com.raylan.fangx.model.DeviceProfile
import com.raylan.fangx.model.FreeFireVersion
import com.raylan.fangx.model.GeneratedSensiRecommendation
import com.raylan.fangx.model.LogStatus
import com.raylan.fangx.model.MainTab
import com.raylan.fangx.model.ModuleId
import com.raylan.fangx.model.OptimizationModule
import com.raylan.fangx.model.SensitivityProfile
import com.raylan.fangx.model.ShizukuStatus
import com.raylan.fangx.model.TerminalLogEntry
import com.raylan.fangx.overlay.FloatingCrosshairService
import com.raylan.fangx.security.SecurityGuard
import com.raylan.fangx.security.SecurityState
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class FangxUiState(
    val securityState: SecurityState = SecurityState.Verified,
    val selectedTab: MainTab = MainTab.MIRA,
    val deviceProfile: DeviceProfile,
    val shizukuStatus: ShizukuStatus = ShizukuStatus.NOT_RUNNING,
    val modules: List<OptimizationModule> = emptyList(),
    val selectedFreeFire: FreeFireVersion = FreeFireVersion.NORMAL,
    val sensitivity: SensitivityProfile = SensitivityProfile(),
    val generatedRecommendation: GeneratedSensiRecommendation? = null,
    val dpiInput: Int = 580,
    val dpiStatusMessage: String? = null,
    val crosshairConfig: CrosshairConfig = CrosshairConfig(),
    val hasOverlayPermission: Boolean = false,
    val isInjecting: Boolean = false,
    val injectionComplete: Boolean = false,
    val showTerminalModal: Boolean = false,
    val injectionProgress: Int = 0,
    val injectionTotal: Int = 0,
    val terminalLogs: List<TerminalLogEntry> = emptyList(),
    val statusBannerMessage: String? = null
) {
    val activeCommandCount: Int
        get() = modules
            .filter { it.isEnabled && it.isCompatible }
            .sumOf { module ->
                module.commands.count { deviceProfile.sdkInt in it.minSdk..it.maxSdk }
            }

    val totalCommandBankCount: Int
        get() = modules.sumOf { it.commands.size }
}

class FangxViewModel(application: Application) : AndroidViewModel(application) {

    private val initialProfile = DeviceCompatibilityScanner.scanDevice(application)
    private val initialSelection = mapOf(
        ModuleId.AIMBOT to true,
        ModuleId.NO_RECOIL to true,
        ModuleId.BONECO_LENTO to true
    )

    private val _uiState = MutableStateFlow(
        FangxUiState(
            securityState = SecurityGuard.verifyIntegrity(application),
            deviceProfile = initialProfile,
            shizukuStatus = ShizukuCommandExecutor.refreshShizukuStatus(),
            modules = CommandRepository.buildModules(initialProfile, initialSelection),
            selectedFreeFire = if (!initialProfile.freeFireNormalInstalled && initialProfile.freeFireMaxInstalled) {
                FreeFireVersion.MAX
            } else {
                FreeFireVersion.NORMAL
            },
            dpiInput = initialProfile.currentDpi.coerceIn(320, 960),
            hasOverlayPermission = runCatching { Settings.canDrawOverlays(application) }.getOrDefault(false)
        )
    )
    val uiState: StateFlow<FangxUiState> = _uiState.asStateFlow()

    private var injectionJob: Job? = null

    init {
        ShizukuCommandExecutor.registerListeners()
        observeSecurityIntegrity()
        observeShizukuStatus()
        observeOverlayRunningState()
    }

    private fun observeSecurityIntegrity() {
        viewModelScope.launch {
            SecurityGuard.observeIntegrity(getApplication()).collectLatest { state ->
                _uiState.update { it.copy(securityState = state) }
            }
        }
    }

    private fun observeShizukuStatus() {
        viewModelScope.launch {
            ShizukuCommandExecutor.shizukuStatus.collectLatest { status ->
                _uiState.update { it.copy(shizukuStatus = status) }
            }
        }
    }

    private fun observeOverlayRunningState() {
        viewModelScope.launch {
            FloatingCrosshairService.isServiceRunning.collectLatest { running ->
                _uiState.update { current ->
                    if (current.crosshairConfig.enabled != running) {
                        current.copy(crosshairConfig = current.crosshairConfig.copy(enabled = running))
                    } else {
                        current
                    }
                }
            }
        }
    }

    fun onAppResume() {
        val context = getApplication<Application>()
        val secState = SecurityGuard.verifyIntegrity(context)
        val hasOverlay = runCatching { Settings.canDrawOverlays(context) }.getOrDefault(false)
        val currentTargetHz = _uiState.value.deviceProfile.selectedTargetHz
        val scanned = DeviceCompatibilityScanner.scanDevice(context, currentTargetHz)
        val selectionMap = _uiState.value.modules.associate { it.id to it.isEnabled }
        val updatedModules = CommandRepository.buildModules(scanned, selectionMap)
        val shizuku = ShizukuCommandExecutor.refreshShizukuStatus()

        _uiState.update {
            it.copy(
                securityState = secState,
                deviceProfile = scanned,
                modules = updatedModules,
                shizukuStatus = shizuku,
                hasOverlayPermission = hasOverlay
            )
        }
    }

    fun selectTab(tab: MainTab) {
        _uiState.update { it.copy(selectedTab = tab) }
    }

    /**
     * Apenas marca/desmarca o módulo. Nenhuma função é aplicada antes de clicar em INJETAR.
     */
    fun toggleModule(moduleId: ModuleId) {
        _uiState.update { current ->
            val updated = current.modules.map { module ->
                if (module.id == moduleId && module.isCompatible) {
                    module.copy(isEnabled = !module.isEnabled)
                } else {
                    module
                }
            }
            current.copy(modules = updated)
        }
    }

    fun selectAllCategory(enable: Boolean, isMira: Boolean) {
        _uiState.update { current ->
            val updated = current.modules.map { module ->
                val matchesCategory = if (isMira) {
                    module.category == com.raylan.fangx.model.ModuleCategory.MIRA
                } else {
                    module.category == com.raylan.fangx.model.ModuleCategory.PERFORMANCE
                }
                if (matchesCategory && module.isCompatible) {
                    module.copy(isEnabled = enable)
                } else {
                    module
                }
            }
            current.copy(modules = updated)
        }
    }

    fun selectTargetHz(hz: Int) {
        val context = getApplication<Application>()
        val updatedProfile = DeviceCompatibilityScanner.scanDevice(context, hz)
        val selectionMap = _uiState.value.modules.associate { it.id to it.isEnabled }
        _uiState.update {
            it.copy(
                deviceProfile = updatedProfile,
                modules = CommandRepository.buildModules(updatedProfile, selectionMap)
            )
        }
    }

    fun selectFreeFireVersion(version: FreeFireVersion) {
        _uiState.update { it.copy(selectedFreeFire = version) }
    }

    fun requestShizukuPermission() {
        val context = getApplication<Application>()
        val started = ShizukuCommandExecutor.requestShizukuPermission(context)
        if (!started && _uiState.value.shizukuStatus == ShizukuStatus.NOT_RUNNING) {
            _uiState.update {
                it.copy(
                    statusBannerMessage = "Shizuku não está em execução. Inicie o serviço Shizuku ou execute em modo seguro."
                )
            }
        }
    }

    fun dismissBannerMessage() {
        _uiState.update { it.copy(statusBannerMessage = null) }
    }

    // --- Sensi Infinita (100 a 200) & DPI ---

    fun updateSensitivity(
        geral: Int = _uiState.value.sensitivity.geral,
        redDot: Int = _uiState.value.sensitivity.redDot,
        scope2x: Int = _uiState.value.sensitivity.scope2x,
        scope4x: Int = _uiState.value.sensitivity.scope4x,
        awm: Int = _uiState.value.sensitivity.awm,
        olhadinha: Int = _uiState.value.sensitivity.olhadinha
    ) {
        _uiState.update {
            it.copy(
                sensitivity = SensitivityProfile(
                    geral = geral.coerceIn(100, 200),
                    redDot = redDot.coerceIn(100, 200),
                    scope2x = scope2x.coerceIn(100, 200),
                    scope4x = scope4x.coerceIn(100, 200),
                    awm = awm.coerceIn(100, 200),
                    olhadinha = olhadinha.coerceIn(100, 200)
                )
            )
        }
    }

    fun generatePerfectSensitivity() {
        val recommendation = DeviceCompatibilityScanner.generatePerfectSensitivity(_uiState.value.deviceProfile)
        _uiState.update {
            it.copy(
                sensitivity = recommendation.profile,
                generatedRecommendation = recommendation,
                dpiInput = recommendation.idealDpi,
                dpiStatusMessage = null
            )
        }
    }

    fun updateDpiInput(dpi: Int) {
        _uiState.update { it.copy(dpiInput = dpi.coerceIn(280, 1000)) }
    }

    fun applyDpiViaShizuku() {
        val targetDpi = _uiState.value.dpiInput
        viewModelScope.launch {
            val result = ShizukuCommandExecutor.applyDpi(targetDpi)
            _uiState.update {
                it.copy(dpiStatusMessage = "wm density $targetDpi -> ${result.detail}")
            }
        }
    }

    fun restoreDefaultDpiViaShizuku() {
        viewModelScope.launch {
            val result = ShizukuCommandExecutor.restoreDefaultDpi()
            val defaultDpi = _uiState.value.deviceProfile.defaultDpi
            _uiState.update {
                it.copy(
                    dpiInput = defaultDpi,
                    dpiStatusMessage = "DPI padrão restaurada (wm density reset) -> ${result.detail}"
                )
            }
        }
    }

    // --- Mira Flutuante ---

    fun toggleFloatingCrosshair(): Boolean {
        val context = getApplication<Application>()
        val canDraw = runCatching { Settings.canDrawOverlays(context) }.getOrDefault(false)
        if (!canDraw) {
            _uiState.update { it.copy(hasOverlayPermission = false) }
            return false
        }

        val currentlyEnabled = _uiState.value.crosshairConfig.enabled
        val newConfig = _uiState.value.crosshairConfig.copy(enabled = !currentlyEnabled)
        _uiState.update { it.copy(crosshairConfig = newConfig, hasOverlayPermission = true) }

        if (newConfig.enabled) {
            FloatingCrosshairService.start(context, newConfig)
        } else {
            FloatingCrosshairService.stop(context)
        }
        return true
    }

    fun openOverlayPermissionSettings() {
        val context = getApplication<Application>()
        runCatching {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }

    fun updateCrosshairShape(shape: CrosshairShape) {
        updateCrosshairConfig { it.copy(shape = shape) }
    }

    fun updateCrosshairColor(color: CrosshairColorOption) {
        updateCrosshairConfig { it.copy(colorOption = color) }
    }

    fun updateCrosshairSize(sizeDp: Float) {
        updateCrosshairConfig { it.copy(sizeDp = sizeDp.coerceIn(16f, 72f)) }
    }

    fun updateCrosshairOpacity(opacity: Float) {
        updateCrosshairConfig { it.copy(opacity = opacity.coerceIn(0.2f, 1.0f)) }
    }

    private fun updateCrosshairConfig(transform: (CrosshairConfig) -> CrosshairConfig) {
        val updated = transform(_uiState.value.crosshairConfig)
        _uiState.update { it.copy(crosshairConfig = updated) }
        FloatingCrosshairService.updateConfig(updated)
    }

    // --- Injeção Cadenciada Anti-Conflito & Abertura Automática do FF ---

    fun startCadencedInjectionAndLaunch() {
        if (_uiState.value.isInjecting) return
        val context = getApplication<Application>()
        if (SecurityGuard.verifyIntegrity(context) is SecurityState.Tampered) return

        val profile = _uiState.value.deviceProfile
        val commands = CommandRepository.filterApplicableCommands(
            modules = _uiState.value.modules,
            sdkInt = profile.sdkInt
        )

        if (commands.isEmpty()) {
            _uiState.update {
                it.copy(
                    statusBannerMessage = "Selecione pelo menos 1 módulo compatível antes de injetar."
                )
            }
            return
        }

        val targetGame = _uiState.value.selectedFreeFire

        injectionJob?.cancel()
        injectionJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isInjecting = true,
                    injectionComplete = false,
                    showTerminalModal = true,
                    injectionProgress = 0,
                    injectionTotal = commands.size,
                    terminalLogs = listOf(
                        TerminalLogEntry(
                            index = 0,
                            total = commands.size,
                            command = "fangx-engine --vendor=${profile.vendorBrand.name} --sdk=${profile.sdkInt}",
                            status = LogStatus.INFO,
                            detail = "Iniciando fila cadenciada (40ms anti-conflito) | Alvo: ${targetGame.displayName}"
                        )
                    )
                )
            }

            commands.forEachIndexed { idx, cmd ->
                val step = idx + 1
                val result = ShizukuCommandExecutor.executeCommand(cmd.command)
                val entry = TerminalLogEntry(
                    index = step,
                    total = commands.size,
                    command = cmd.command,
                    status = result.status,
                    detail = result.detail
                )

                _uiState.update { state ->
                    state.copy(
                        injectionProgress = step,
                        terminalLogs = (state.terminalLogs + entry).takeLast(120)
                    )
                }

                // Atraso controlado de 40ms entre comandos para evitar conflitos no Shizuku/Android
                delay(40L)
            }

            val launchResult = ShizukuCommandExecutor.launchFreeFire(context, targetGame)
            val launchLog = if (launchResult.isSuccess) {
                TerminalLogEntry(
                    index = commands.size,
                    total = commands.size,
                    command = "am start ${targetGame.packageName}",
                    status = LogStatus.SUCCESS,
                    detail = "Injeção finalizada! Abrindo ${targetGame.displayName}..."
                )
            } else {
                TerminalLogEntry(
                    index = commands.size,
                    total = commands.size,
                    command = "am start ${targetGame.packageName}",
                    status = LogStatus.WARN,
                    detail = "${targetGame.displayName} não instalado neste dispositivo. Comandos concluídos!"
                )
            }

            _uiState.update { state ->
                state.copy(
                    isInjecting = false,
                    injectionComplete = true,
                    terminalLogs = state.terminalLogs + launchLog
                )
            }
        }
    }

    fun closeTerminalModal() {
        if (!_uiState.value.isInjecting) {
            _uiState.update { it.copy(showTerminalModal = false) }
        }
    }

    fun rescanCompatibility() {
        onAppResume()
        _uiState.update {
            it.copy(statusBannerMessage = "Scanner de compatibilidade atualizado com sucesso.")
        }
    }

    override fun onCleared() {
        super.onCleared()
        ShizukuCommandExecutor.unregisterListeners()
    }
}
