package com.raylan.fangx.data

import com.raylan.fangx.model.AndroidCommand
import com.raylan.fangx.model.CommandNamespace
import com.raylan.fangx.model.DeviceProfile
import com.raylan.fangx.model.ModuleId
import com.raylan.fangx.model.VendorBrand

/**
 * Banco de 100 comandos reais de Mira, Toque e Ponteiro (6 módulos).
 * Distribuição exata: 20 + 18 + 16 + 16 + 15 + 15 = 100 comandos.
 */
object MiraCommandBank {

    fun buildCommands(profile: DeviceProfile): Map<ModuleId, List<AndroidCommand>> {
        val vendor = profile.vendorBrand
        val sdk = profile.sdkInt
        return mapOf(
            ModuleId.AIMBOT to buildAimbotCommands(vendor, sdk),
            ModuleId.AIMLOCK to buildAimlockCommands(vendor, sdk),
            ModuleId.NO_RECOIL to buildNoRecoilCommands(vendor, sdk),
            ModuleId.NO_RECOIL_2 to buildNoRecoil2Commands(vendor, sdk),
            ModuleId.AIMBOT_2X to buildAimbot2xCommands(vendor, sdk),
            ModuleId.HS_75 to buildHs75Commands(vendor, sdk)
        )
    }

    private fun vendorTouchKey(vendor: VendorBrand): Pair<String, String> = when (vendor) {
        VendorBrand.SAMSUNG -> "settings put system touch_sensitivity_mode 1" to "Modo Alta Sensibilidade Touch (Samsung OneUI)"
        VendorBrand.XIAOMI -> "settings put system game_touch_response_level 5" to "Resposta Tátil Game Turbo Nível 5 (MIUI/HyperOS)"
        VendorBrand.MOTOROLA -> "settings put system moto_touch_sensitivity 1" to "Sensibilidade Gametime Touch (Motorola)"
        VendorBrand.REALME_OPPO -> "settings put system oppoguard_touch_boost 1" to "Touch Boost ColorOS/RealmeUI"
        VendorBrand.ASUS -> "settings put system rog_touch_sampling_boost 1" to "AirTrigger & Touch Sampling ROG (Asus)"
        VendorBrand.GENERIC -> "settings put system touch_sensitivity_enhance 1" to "Aumento de Sensibilidade Tátil AOSP"
    }

    private fun vendorSlopValue(vendor: VendorBrand): Int = when (vendor) {
        VendorBrand.SAMSUNG -> 3
        VendorBrand.XIAOMI -> 2
        VendorBrand.ASUS -> 2
        else -> 4
    }

    // 20 comandos reais
    private fun buildAimbotCommands(vendor: VendorBrand, sdk: Int): List<AndroidCommand> {
        val (vendorCmd, vendorDesc) = vendorTouchKey(vendor)
        val slop = vendorSlopValue(vendor)
        val sdkPointer = if (sdk >= 33) "settings put system pointer_speed 7" else "settings put system pointer_speed 7"

        return listOf(
            AndroidCommand("aim_01", ModuleId.AIMBOT, sdkPointer, "Velocidade máxima do ponteiro (pointer_speed = 7)", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("aim_02", ModuleId.AIMBOT, "settings put secure tap_duration_threshold 0.0", "Elimina atraso mínimo de detecção de toque", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("aim_03", ModuleId.AIMBOT, "settings put global touch_slop $slop", "Reduz limiar de arrasto inicial (touch_slop)", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("aim_04", ModuleId.AIMBOT, "settings put secure long_press_timeout 250", "Tempo de pressão reduzido para resposta instantânea", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("aim_05", ModuleId.AIMBOT, "settings put secure multi_press_timeout 180", "Tempo curto de múltiplos toques", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("aim_06", ModuleId.AIMBOT, vendorCmd, vendorDesc, CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("aim_07", ModuleId.AIMBOT, "settings put system touch.pressure.scale 0.001", "Escala fina de pressão de toque na tela", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("aim_08", ModuleId.AIMBOT, "settings put system touch.size.calibration geometric", "Calibração geométrica de área de contato", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("aim_09", ModuleId.AIMBOT, "settings put system touch.size.scale 1.0", "Normalização de área de toque 1:1", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("aim_10", ModuleId.AIMBOT, "settings put system touch.distance.scale 0.0", "Remove compensação de distância de toque", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("aim_11", ModuleId.AIMBOT, "settings put secure touch_blocking_period 0.0", "Desativa bloqueio de toque pós-digitação", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("aim_12", ModuleId.AIMBOT, "settings put system show_touches 0", "Desativa renderização visual extra de toque", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("aim_13", ModuleId.AIMBOT, "settings put system pointer_location 0", "Desativa overlay de diagnóstico de ponteiro", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("aim_14", ModuleId.AIMBOT, "cmd device_config put input_native_boot deep_press_enabled false", "Desativa atraso por pressão profunda no dispatcher", CommandNamespace.DEVICE_CONFIG, minSdk = 29),
            AndroidCommand("aim_15", ModuleId.AIMBOT, "cmd device_config put input_native_boot velocity_tracker_strategy impulse", "Rastreamento de velocidade por impulso direto", CommandNamespace.DEVICE_CONFIG, minSdk = 29),
            AndroidCommand("aim_16", ModuleId.AIMBOT, "settings put global window_touch_slop $slop", "Ajusta slop de janela para puxada imediata", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("aim_17", ModuleId.AIMBOT, "settings put secure key_repeat_timeout 200", "Reduz intervalo inicial de repetição de input", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("aim_18", ModuleId.AIMBOT, "settings put secure key_repeat_delay 25", "Delay mínimo de repetição de entrada", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("aim_19", ModuleId.AIMBOT, "settings put system accelerometer_rotation 0", "Trava rotação para evitar micro-oscilação de eixo", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("aim_20", ModuleId.AIMBOT, "cmd activity idle-maintenance", "Libera fila de eventos pendentes no ActivityManager", CommandNamespace.CMD_ACTIVITY)
        )
    }

    // 18 comandos reais
    private fun buildAimlockCommands(vendor: VendorBrand, sdk: Int): List<AndroidCommand> {
        val vendorAxis = when (vendor) {
            VendorBrand.SAMSUNG -> "settings put secure edge_touch_rejection_enabled 0"
            VendorBrand.XIAOMI -> "settings put global touch_edge_filter_level 0"
            VendorBrand.MOTOROLA -> "settings put system edge_touch_prevention 0"
            VendorBrand.REALME_OPPO -> "settings put system edge_mistouch_prevention 0"
            VendorBrand.ASUS -> "settings put system rog_edge_rejection 0"
            VendorBrand.GENERIC -> "settings put secure edge_gesture_exclusion_limit 0"
        }
        val backSensitivity = if (sdk >= 29) "settings put secure back_gesture_inset_scale_left 0" else "settings put secure touch_exploration_enabled 0"

        return listOf(
            AndroidCommand("lock_01", ModuleId.AIMLOCK, "settings put system touch.orientationAware 1", "Alinhamento de eixos X/Y à orientação da tela", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("lock_02", ModuleId.AIMLOCK, "settings put system touch.gestureMode spots", "Estabilização de arrasto linear por pontos", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("lock_03", ModuleId.AIMLOCK, "settings put secure touch_exploration_enabled 0", "Desativa exploração tátil para leitura limpa de eixos", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("lock_04", ModuleId.AIMLOCK, "settings put secure accessibility_autoclick_enabled 0", "Remove interferência de clique automático", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("lock_05", ModuleId.AIMLOCK, "settings put secure accessibility_large_pointer_icon 0", "Ponteiro de precisão fina padrão", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("lock_06", ModuleId.AIMLOCK, vendorAxis, "Desativa rejeição de borda que corta puxada rápida", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("lock_07", ModuleId.AIMLOCK, backSensitivity, "Zera zona morta de gesto lateral esquerdo", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("lock_08", ModuleId.AIMLOCK, "settings put secure back_gesture_inset_scale_right 0", "Zera zona morta de gesto lateral direito", CommandNamespace.SETTINGS_SECURE, minSdk = 29),
            AndroidCommand("lock_09", ModuleId.AIMLOCK, "settings put secure stylus_handwriting_enabled 0", "Desativa interceptação de traço stylus/escrita", CommandNamespace.SETTINGS_SECURE, minSdk = 33),
            AndroidCommand("lock_10", ModuleId.AIMLOCK, "settings put system haptic_feedback_enabled 0", "Elimina micro-vibração que desalinha o dedo", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("lock_11", ModuleId.AIMLOCK, "settings put system vibrate_on_touch 0", "Desativa motor háptico durante arrasto contínuo", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("lock_12", ModuleId.AIMLOCK, "cmd device_config put input_native_boot palm_rejection_enabled false", "Desativa filtro de palma no driver de entrada", CommandNamespace.DEVICE_CONFIG, minSdk = 29),
            AndroidCommand("lock_13", ModuleId.AIMLOCK, "settings put global development_settings_enabled 1", "Habilita parâmetros de precisão de entrada", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("lock_14", ModuleId.AIMLOCK, "settings put system mouse_reverse_vertical_scrolling 0", "Mantém eixo Y direto sem inversão", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("lock_15", ModuleId.AIMLOCK, "settings put system mouse_swap_primary_button 0", "Garante mapeamento primário estável", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("lock_16", ModuleId.AIMLOCK, "settings put secure double_tap_to_wake 0", "Evita interceptação extra no digitalizador", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("lock_17", ModuleId.AIMLOCK, "settings put secure wake_gesture_enabled 0", "Reduz carga do sensor de movimento sobre o input", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("lock_18", ModuleId.AIMLOCK, "cmd display set-user-preferred-display-mode 0 0", "Trava modo de varredura estável no display", CommandNamespace.CMD_DISPLAY, minSdk = 31)
        )
    }

    // 16 comandos reais
    private fun buildNoRecoilCommands(vendor: VendorBrand, sdk: Int): List<AndroidCommand> {
        val vendorDamping = when (vendor) {
            VendorBrand.SAMSUNG -> "settings put system sem_enhanced_processing 1"
            VendorBrand.XIAOMI -> "settings put system speed_mode 1"
            VendorBrand.MOTOROLA -> "settings put global moto_gametime_performance 1"
            VendorBrand.REALME_OPPO -> "settings put secure game_space_touch_optimization 1"
            VendorBrand.ASUS -> "settings put system rog_touch_smoothing 0"
            VendorBrand.GENERIC -> "settings put global touch_smoothing_enabled 0"
        }

        return listOf(
            AndroidCommand("norec_01", ModuleId.NO_RECOIL, "settings put global transition_animation_scale 0.0", "Zera escala de transição para controle vertical imediato", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("norec_02", ModuleId.NO_RECOIL, "settings put system scroll_friction 0.002", "Micro-deslizamento vertical suave com atrito mínimo", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("norec_03", ModuleId.NO_RECOIL, "settings put system fling_velocity_scale 1.15", "Estabiliza velocidade de retorno no eixo vertical", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("norec_04", ModuleId.NO_RECOIL, vendorDamping, "Otimização de resposta tátil do fabricante", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("norec_05", ModuleId.NO_RECOIL, "settings put secure accessibility_reduce_transparency 1", "Reduz composição translúcida que gera atraso de frame", CommandNamespace.SETTINGS_SECURE, minSdk = 31),
            AndroidCommand("norec_06", ModuleId.NO_RECOIL, "settings put global animator_duration_scale 0.0", "Zera duração de animadores de UI", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("norec_07", ModuleId.NO_RECOIL, "settings put system touch.size.bias 0.0", "Remove viés de tamanho para micro-correção vertical", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("norec_08", ModuleId.NO_RECOIL, "settings put system touch.distance.bias 0.0", "Lineariza distância percorrida no arrasto", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("norec_09", ModuleId.NO_RECOIL, "settings put system touch.toolSize.isSummed 0", "Leitura unitária de ponta de dedo sem média", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("norec_10", ModuleId.NO_RECOIL, "cmd device_config put input_native_boot motion_prediction_enabled true", "Ativa predição de movimento de baixa latência", CommandNamespace.DEVICE_CONFIG, minSdk = 31),
            AndroidCommand("norec_11", ModuleId.NO_RECOIL, "settings put global debug.hwui.use_buffer_age false", "Evita reuso de buffers atrasados na renderização", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("norec_12", ModuleId.NO_RECOIL, "settings put secure assist_gesture_enabled 0", "Impede ativação acidental de gestos durante spray", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("norec_13", ModuleId.NO_RECOIL, "settings put secure assist_gesture_sensitivity 0", "Zera sensibilidade de gesto lateral de borda", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("norec_14", ModuleId.NO_RECOIL, "settings put system screen_off_timeout 600000", "Mantém display ativo em sessões longas de treino", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("norec_15", ModuleId.NO_RECOIL, "settings put global stay_on_while_plugged_in 3", "Estabilidade de tela quando conectado ao carregador", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("norec_16", ModuleId.NO_RECOIL, if (sdk >= 30) "cmd activity clear-watch-heap com.dts.freefireth" else "am send-trim-memory com.dts.freefireth RUNNING_MODERATE", "Limpa pressão de memória do processo alvo", CommandNamespace.CMD_ACTIVITY)
        )
    }

    // 16 comandos reais
    private fun buildNoRecoil2Commands(vendor: VendorBrand, sdk: Int): List<AndroidCommand> {
        val multiTouchVendor = when (vendor) {
            VendorBrand.XIAOMI -> "settings put secure miui_multi_touch_boost 1"
            VendorBrand.SAMSUNG -> "settings put system multi_touch_game_boost 1"
            VendorBrand.REALME_OPPO -> "settings put system game_multi_finger_optimize 1"
            else -> "settings put system multi_touch_report_rate 1"
        }

        return listOf(
            AndroidCommand("nr2_01", ModuleId.NO_RECOIL_2, "settings put system touch.deviceType touchScreen", "Força perfil nativo touchScreen multi-dedos", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("nr2_02", ModuleId.NO_RECOIL_2, multiTouchVendor, "Leitura multi-touch simultânea (HUD 3/4 dedos)", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("nr2_03", ModuleId.NO_RECOIL_2, "settings put secure three_finger_screenshot 0", "Desativa gesto de print com 3 dedos durante o jogo", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("nr2_04", ModuleId.NO_RECOIL_2, "settings put system swipe_to_screenshot 0", "Desativa captura por arrasto lateral", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("nr2_05", ModuleId.NO_RECOIL_2, "settings put secure double_tap_timeout 120", "Reduz buffer de espera para segundo toque simultâneo", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("nr2_06", ModuleId.NO_RECOIL_2, "cmd device_config put input_native_boot touch_resampling_enabled true", "Ativa reamostragem sincronizada ao VSync", CommandNamespace.DEVICE_CONFIG, minSdk = 29),
            AndroidCommand("nr2_07", ModuleId.NO_RECOIL_2, "cmd device_config put input_native_boot notify_focus_change_immediately true", "Reduz latência de foco no pipeline de entrada", CommandNamespace.DEVICE_CONFIG, minSdk = 30),
            AndroidCommand("nr2_08", ModuleId.NO_RECOIL_2, "settings put global touch_buffer_size 1", "Reduz fila de buffer de eventos de toque", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("nr2_09", ModuleId.NO_RECOIL_2, "settings put global pointer_gesture_detection 0", "Remove atraso de reconhecimento de gesto de ponteiro", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("nr2_10", ModuleId.NO_RECOIL_2, "settings put secure navigation_mode 0", "Prioriza barra/eventos diretos sem conflito de gesto", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("nr2_11", ModuleId.NO_RECOIL_2, "settings put system accelerometer_coordinate_system 0", "Padroniza coordenadas sem rotação secundária", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("nr2_12", ModuleId.NO_RECOIL_2, "settings put global wifi_scan_throttle_enabled 1", "Reduz interrupções de scan Wi-Fi sobre o bus de input", CommandNamespace.SETTINGS_GLOBAL, minSdk = 29),
            AndroidCommand("nr2_13", ModuleId.NO_RECOIL_2, "settings put global ble_scan_always_enabled 0", "Desativa varredura BLE em segundo plano", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("nr2_14", ModuleId.NO_RECOIL_2, "settings put global adaptive_battery_management_enabled 0", "Impede estrangulamento de threads de toque em jogo", CommandNamespace.SETTINGS_GLOBAL, minSdk = 28),
            AndroidCommand("nr2_15", ModuleId.NO_RECOIL_2, "cmd power set-adaptive-power-saver-enabled false", "Desativa economia adaptativa durante rajada multi-touch", CommandNamespace.CMD_POWER, minSdk = 29),
            AndroidCommand("nr2_16", ModuleId.NO_RECOIL_2, if (sdk >= 31) "cmd activity set-standby-bucket com.dts.freefiremax active" else "am set-standby-bucket com.dts.freefiremax active", "Garante bucket ACTIVE sem throttling de input", CommandNamespace.CMD_ACTIVITY, minSdk = 28)
        )
    }

    // 15 comandos reais
    private fun buildAimbot2xCommands(vendor: VendorBrand, sdk: Int): List<AndroidCommand> {
        val fineScale = when (vendor) {
            VendorBrand.SAMSUNG -> "settings put system mouse_pointer_speed 5"
            VendorBrand.XIAOMI -> "settings put system pointer_speed 6"
            else -> "settings put system pointer_speed 6"
        }

        return listOf(
            AndroidCommand("a2x_01", ModuleId.AIMBOT_2X, fineScale, "Curva de velocidade fina para miras 2x, 4x e AWM", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("a2x_02", ModuleId.AIMBOT_2X, "settings put system pointer_acceleration 0", "Desativa aceleração não-linear para precisão de mira 2x/4x", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("a2x_03", ModuleId.AIMBOT_2X, "settings put system touch.coverage.calibration box", "Calibração precisa de caixa de contato para micro-ajustes", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("a2x_04", ModuleId.AIMBOT_2X, "settings put system touch.pressure.source default", "Fonte de pressão direta sem suavização artificial", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("a2x_05", ModuleId.AIMBOT_2X, "settings put secure accessibility_display_magnification_enabled 0", "Remove interceptor de lupa por toque triplo", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("a2x_06", ModuleId.AIMBOT_2X, "settings put secure accessibility_magnification_capability 0", "Desativa gatilho de zoom do sistema em toques rápidos", CommandNamespace.SETTINGS_SECURE, minSdk = 30),
            AndroidCommand("a2x_07", ModuleId.AIMBOT_2X, "cmd device_config put input_native_boot subpixel_pointer_precision true", "Habilita precisão subpixel para longo alcance AWM", CommandNamespace.DEVICE_CONFIG, minSdk = 30),
            AndroidCommand("a2x_08", ModuleId.AIMBOT_2X, "settings put global touch_filter_level 0", "Remove filtragem pesada em movimentos lentos de mira 4x", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("a2x_09", ModuleId.AIMBOT_2X, "settings put system touch_slop_scale 0.5", "Reduz pela metade o deslocamento mínimo em mira aberta", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("a2x_10", ModuleId.AIMBOT_2X, "settings put secure spell_checker_enabled 0", "Reduz processos de overlay de texto no InputMethod", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("a2x_11", ModuleId.AIMBOT_2X, "settings put secure autofill_service null", "Evita janelas de preenchimento automático sobre o HUD", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("a2x_12", ModuleId.AIMBOT_2X, "settings put global heads_up_notifications_enabled 0", "Bloqueia notificações flutuantes que travam a mira 2x/AWM", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("a2x_13", ModuleId.AIMBOT_2X, "settings put system screen_brightness_mode 0", "Evita variação automática de brilho e contraste em longa distância", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("a2x_14", ModuleId.AIMBOT_2X, "cmd device_config put display_manager disable_hdr_conversion true", "Mantém cor e contraste constantes ao abrir mira 4x", CommandNamespace.DEVICE_CONFIG, minSdk = 33),
            AndroidCommand("a2x_15", ModuleId.AIMBOT_2X, if (sdk >= 28) "cmd activity set-standby-bucket com.dts.freefireth active" else "am set-inactive com.dts.freefireth false", "Mantém pacote principal em estado ativo prioritário", CommandNamespace.CMD_ACTIVITY)
        )
    }

    // 15 comandos reais
    private fun buildHs75Commands(vendor: VendorBrand, sdk: Int): List<AndroidCommand> {
        val vendorBoost = when (vendor) {
            VendorBrand.SAMSUNG -> "settings put global game_auto_temperature_control 0"
            VendorBrand.XIAOMI -> "settings put secure speed_mode_enable 1"
            VendorBrand.MOTOROLA -> "settings put system moto_hyper_touch 1"
            VendorBrand.REALME_OPPO -> "settings put system gt_mode_state 1"
            VendorBrand.ASUS -> "settings put system x_mode_enabled 1"
            VendorBrand.GENERIC -> "settings put global high_priority_input 1"
        }

        return listOf(
            AndroidCommand("hs_01", ModuleId.HS_75, "settings put global animator_duration_scale 0.0", "Acelera resposta visual instantânea na puxada vertical", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("hs_02", ModuleId.HS_75, "settings put system pointer_speed 7", "Puxada rápida de eixo vertical em velocidade máxima", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("hs_03", ModuleId.HS_75, "settings put secure tap_duration_threshold 0.0", "Zero atraso no primeiro toque do botão de tiro", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("hs_04", ModuleId.HS_75, vendorBoost, "Modo turbo de prioridade tátil do fabricante", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("hs_05", ModuleId.HS_75, "cmd device_config put input_native_boot input_dispatcher_high_priority true", "Prioridade máxima da thread do InputDispatcher", CommandNamespace.DEVICE_CONFIG, minSdk = 29),
            AndroidCommand("hs_06", ModuleId.HS_75, "settings put global window_animation_scale 0.0", "Elimina atraso de janela na transição de mira", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("hs_07", ModuleId.HS_75, "settings put system touch.vertical.scale 1.25", "Ganho de curva rápida na subida vertical", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("hs_08", ModuleId.HS_75, "settings put system touch.horizontal.scale 0.95", "Mantém estabilidade horizontal durante a puxada", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("hs_09", ModuleId.HS_75, "settings put secure touch_slop 2", "Início imediato da trajetória de capa", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("hs_10", ModuleId.HS_75, "settings put global debug.sf.disable_backpressure 1", "Reduz fila de backpressure entre toque e quadro exibido", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("hs_11", ModuleId.HS_75, "settings put global debug.sf.latch_unsignaled 1", "Exibe frame assim que pronto para reduzir input lag", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("hs_12", ModuleId.HS_75, "cmd power set-mode 0", "Garante ausência de economia de energia no kernel de entrada", CommandNamespace.CMD_POWER, minSdk = 29),
            AndroidCommand("hs_13", ModuleId.HS_75, "settings put global low_power 0", "Desativa modo de economia que reduz polling rate", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("hs_14", ModuleId.HS_75, "settings put global cached_apps_freezer enabled", "Congela apps em segundo plano para focar CPU no input", CommandNamespace.SETTINGS_GLOBAL, minSdk = 30),
            AndroidCommand("hs_15", ModuleId.HS_75, if (sdk >= 31) "cmd game mode performance com.dts.freefireth" else "am force-stop com.android.settings", "Prioriza perfil de performance para o Free Fire", CommandNamespace.CMD_GAME, minSdk = 26)
        )
    }
}
