package com.raylan.fangx.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.raylan.fangx.MainActivity
import com.raylan.fangx.R
import com.raylan.fangx.model.CrosshairConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class FloatingCrosshairService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: CrosshairOverlayView? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundSafely()
        attachOverlay()
        serviceScope.launch {
            liveConfigFlow.collectLatest { config ->
                updateOverlayLayout(config)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        serviceScope.cancel()
        detachOverlay()
        isServiceRunning.value = false
        super.onDestroy()
    }

    private fun startForegroundSafely() {
        runCatching {
            val channelId = CHANNEL_ID
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            if (manager != null && manager.getNotificationChannel(channelId) == null) {
                val channel = NotificationChannel(
                    channelId,
                    getString(R.string.overlay_channel_name),
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = getString(R.string.overlay_notification_text)
                    setShowBadge(false)
                }
                manager.createNotificationChannel(channel)
            }

            val launchIntent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingIntent = PendingIntent.getActivity(
                this,
                0,
                launchIntent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

            val notification: Notification = NotificationCompat.Builder(this, channelId)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(getString(R.string.overlay_notification_title))
                .setContentText(getString(R.string.overlay_notification_text))
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .setSilent(true)
                .build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            isServiceRunning.value = true
        }
    }

    private fun attachOverlay() {
        runCatching {
            if (!Settings.canDrawOverlays(this)) {
                stopSelf()
                return
            }
            val wm = getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
            windowManager = wm
            val view = CrosshairOverlayView(this).apply {
                updateConfig(liveConfigFlow.value)
            }
            val params = buildLayoutParams(liveConfigFlow.value)
            wm.addView(view, params)
            overlayView = view
        }
    }

    private fun updateOverlayLayout(config: CrosshairConfig) {
        runCatching {
            val view = overlayView ?: return
            val wm = windowManager ?: return
            view.updateConfig(config)
            wm.updateViewLayout(view, buildLayoutParams(config))
        }
    }

    private fun buildLayoutParams(config: CrosshairConfig): WindowManager.LayoutParams {
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            x = config.offsetX
            y = config.offsetY
        }
    }

    private fun detachOverlay() {
        runCatching {
            val view = overlayView
            if (view != null) {
                windowManager?.removeViewImmediate(view)
            }
            overlayView = null
        }
    }

    companion object {
        private const val CHANNEL_ID = "fangx_overlay_channel"
        private const val NOTIFICATION_ID = 4075
        private const val ACTION_STOP = "com.raylan.fangx.ACTION_STOP_OVERLAY"

        val liveConfigFlow = MutableStateFlow(CrosshairConfig())
        val isServiceRunning = MutableStateFlow(false)

        fun updateConfig(config: CrosshairConfig) {
            liveConfigFlow.value = config
        }

        fun start(context: Context, config: CrosshairConfig) {
            liveConfigFlow.value = config
            runCatching {
                val intent = Intent(context, FloatingCrosshairService::class.java)
                context.startForegroundService(intent)
            }
        }

        fun stop(context: Context) {
            runCatching {
                context.stopService(Intent(context, FloatingCrosshairService::class.java))
            }
            isServiceRunning.value = false
        }
    }
}
