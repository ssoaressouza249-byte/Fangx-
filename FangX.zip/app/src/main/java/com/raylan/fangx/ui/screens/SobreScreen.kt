package com.raylan.fangx.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeveloperBoard
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.raylan.fangx.engine.CoreModuleSignatures
import com.raylan.fangx.model.DeviceProfile
import com.raylan.fangx.ui.theme.FangxBg
import com.raylan.fangx.ui.theme.FangxBorder
import com.raylan.fangx.ui.theme.FangxCyan
import com.raylan.fangx.ui.theme.FangxGreen
import com.raylan.fangx.ui.theme.FangxRed
import com.raylan.fangx.ui.theme.FangxSurface
import com.raylan.fangx.ui.theme.FangxSurfaceElevated
import com.raylan.fangx.ui.theme.FangxTextPrimary
import com.raylan.fangx.ui.theme.FangxTextSecondary

@Composable
fun SobreScreen(
    deviceProfile: DeviceProfile,
    totalCommandsCount: Int,
    onRescanDevice: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .fillMaxSize()
            .testTag("screen_sobre")
    ) {
        // 1. SCANNER DE COMPATIBILIDADE
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = FangxSurface,
                border = BorderStroke(1.dp, FangxBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 640.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.DeveloperBoard,
                            contentDescription = null,
                            tint = FangxCyan,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SCANNER DE COMPATIBILIDADE",
                            style = MaterialTheme.typography.titleMedium,
                            color = FangxTextPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    TelemetryRow("Fabricante", "${deviceProfile.manufacturer} (${deviceProfile.vendorBrand.displayName})")
                    TelemetryRow("Modelo", deviceProfile.model)
                    TelemetryRow("Android / SDK", "Android ${deviceProfile.androidRelease} (API ${deviceProfile.sdkInt})")
                    TelemetryRow("Resolução / DPI", "${deviceProfile.widthPx}x${deviceProfile.heightPx} • ${deviceProfile.currentDpi} dpi")
                    TelemetryRow("Taxas de Hz suportadas", deviceProfile.supportedRefreshRates.joinToString(" / ") { "${it}Hz" })
                    TelemetryRow("Banco de Comandos", "$totalCommandsCount comandos reais (100 Mira + 100 FPS)")

                    Spacer(modifier = Modifier.height(8.dp))

                    val ns = deviceProfile.namespaceSupport
                    NamespaceBadgeRow("settings system/secure/global", ns.settingsSystem && ns.settingsSecure && ns.settingsGlobal)
                    NamespaceBadgeRow("cmd device_config / power / thermal", ns.deviceConfig && ns.cmdPower && ns.cmdThermal)
                    NamespaceBadgeRow("cmd game / GameManager (API 31+)", ns.cmdGame)
                    NamespaceBadgeRow("Free Fire Normal (com.dts.freefireth)", deviceProfile.freeFireNormalInstalled)
                    NamespaceBadgeRow("Free Fire MAX (com.dts.freefiremax)", deviceProfile.freeFireMaxInstalled)

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = onRescanDevice,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = FangxSurfaceElevated,
                            contentColor = FangxCyan
                        ),
                        border = BorderStroke(1.dp, FangxCyan),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("rescan_device_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "REESCANEAR COMPATIBILIDADE",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }
        }

        // 2. PROTEÇÃO ANTI-MODIFICAÇÃO
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = FangxSurface,
                border = BorderStroke(1.dp, FangxGreen.copy(alpha = 0.55f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 640.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.VerifiedUser,
                            contentDescription = null,
                            tint = FangxGreen,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SECURITYGUARD ANTI-MODIFICAÇÃO",
                            style = MaterialTheme.typography.titleMedium,
                            color = FangxGreen
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Integridade verificada em tempo real: nome oficial 'Fangx', pacote 'com.raylan.fangx' e assinaturas protegidas (${CoreModuleSignatures.requiredTokens().joinToString(", ")}).",
                        style = MaterialTheme.typography.bodyMedium,
                        color = FangxTextSecondary
                    )
                }
            }
        }

        // 3. CRÉDITOS OFICIAIS
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = FangxBg,
                border = BorderStroke(1.dp, FangxCyan.copy(alpha = 0.45f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 640.dp)
                    .testTag("about_credits_card")
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(18.dp)
                ) {
                    Text(
                        text = "FANGX OFFICIAL",
                        style = MaterialTheme.typography.titleSmall,
                        color = FangxCyan
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Desenvolvido por Raylan • Fangx Official",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                        color = FangxTextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Versão oficial blindada • Otimização Android & Shizuku",
                        style = MaterialTheme.typography.labelSmall,
                        color = FangxTextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun TelemetryRow(label: String, value: String) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = FangxTextSecondary
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            color = FangxTextPrimary
        )
    }
}

@Composable
private fun NamespaceBadgeRow(name: String, supported: Boolean) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
    ) {
        Text(
            text = name,
            style = MaterialTheme.typography.bodySmall,
            color = FangxTextSecondary
        )
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = if (supported) FangxGreen.copy(alpha = 0.14f) else FangxRed.copy(alpha = 0.14f)
        ) {
            Text(
                text = if (supported) "COMPATÍVEL" else "INDISPONÍVEL",
                style = MaterialTheme.typography.labelSmall,
                color = if (supported) FangxGreen else FangxRed,
                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
            )
        }
    }
}
