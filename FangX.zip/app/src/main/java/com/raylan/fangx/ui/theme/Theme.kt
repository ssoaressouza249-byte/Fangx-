package com.raylan.fangx.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val FangxDarkColorScheme = darkColorScheme(
    primary = FangxCyan,
    onPrimary = FangxBg,
    primaryContainer = FangxCyanDim.copy(alpha = 0.22f),
    onPrimaryContainer = FangxCyan,
    secondary = FangxRed,
    onSecondary = FangxTextPrimary,
    secondaryContainer = FangxRedDim.copy(alpha = 0.25f),
    onSecondaryContainer = FangxRed,
    tertiary = FangxGreen,
    onTertiary = FangxBg,
    background = FangxBg,
    onBackground = FangxTextPrimary,
    surface = FangxSurface,
    onSurface = FangxTextPrimary,
    surfaceVariant = FangxSurfaceElevated,
    onSurfaceVariant = FangxTextSecondary,
    outline = FangxBorder,
    outlineVariant = FangxBorder.copy(alpha = 0.6f),
    error = FangxRed,
    onError = FangxTextPrimary
)

private val FangxShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun FangxTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = FangxDarkColorScheme,
        typography = FangxTypography,
        shapes = FangxShapes,
        content = content
    )
}
