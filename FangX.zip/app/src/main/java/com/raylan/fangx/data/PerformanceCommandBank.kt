package com.raylan.fangx.data

import com.raylan.fangx.model.AndroidCommand
import com.raylan.fangx.model.CommandNamespace
import com.raylan.fangx.model.DeviceProfile
import com.raylan.fangx.model.ModuleId
import com.raylan.fangx.model.VendorBrand

/**
 * Banco de 100 comandos reais de Desempenho, CPU, GPU, Hz, FPS e Sistema (5 módulos).
 * Distribuição exata: 20 + 15 + 25 + 20 + 20 = 100 comandos.
 */
object PerformanceCommandBank {

    fun buildCommands(profile: DeviceProfile): Map<ModuleId, List<AndroidCommand>> {
        val vendor = profile.vendorBrand
        val sdk = profile.sdkInt
        val targetHz = profile.selectedTargetHz.coerceAtLeast(60)
        return mapOf(
            ModuleId.BONECO_LENTO to buildBonecoLentoCommands(vendor, sdk),
            ModuleId.FORCE_HZ to buildForceHzCommands(vendor, sdk, targetHz),
            ModuleId.TURBO_BOOST to buildTurboBoostCommands(vendor, sdk),
            ModuleId.LOCK_FPS to buildLockFpsCommands(vendor, sdk),
            ModuleId.LIGHT_UI to buildLightUiCommands(vendor, sdk)
        )
    }

    // 20 comandos reais
    private fun buildBonecoLentoCommands(vendor: VendorBrand, sdk: Int): List<AndroidCommand> {
        val vendorAnim = when (vendor) {
            VendorBrand.SAMSUNG -> "settings put global reduce_motion 1"
            VendorBrand.XIAOMI -> "settings put global miui_animation_level 0"
            else -> "settings put global remove_animations 1"
        }

        return listOf(
            AndroidCommand("bl_01", ModuleId.BONECO_LENTO, "settings put global window_animation_scale 0.0", "Fluidez extrema: escala de janela 0.0", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("bl_02", ModuleId.BONECO_LENTO, "settings put global transition_animation_scale 0.0", "Fluidez extrema: escala de transição 0.0", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("bl_03", ModuleId.BONECO_LENTO, "settings put global animator_duration_scale 0.0", "Fluidez extrema: duração de animador 0.0", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("bl_04", ModuleId.BONECO_LENTO, vendorAnim, "Redução de animações pesadas da interface do fabricante", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("bl_05", ModuleId.BONECO_LENTO, "settings put global disable_window_blurs 1", "Desativa desfoque gaussiano em janelas do sistema", CommandNamespace.SETTINGS_GLOBAL, minSdk = 31),
            AndroidCommand("bl_06", ModuleId.BONECO_LENTO, "settings put secure reduce_bright_colors_activated 0", "Desativa filtro extra de escurecimento no compositor", CommandNamespace.SETTINGS_SECURE, minSdk = 31),
            AndroidCommand("bl_07", ModuleId.BONECO_LENTO, "cmd device_config put surface_flinger_native_boot enable_frame_rate_override true", "Habilita frame pacing sincronizado no SurfaceFlinger", CommandNamespace.DEVICE_CONFIG, minSdk = 31),
            AndroidCommand("bl_08", ModuleId.BONECO_LENTO, "cmd device_config put surface_flinger_native_boot use_content_detection_for_refresh_rate false", "Evita oscilação dinâmica de taxa entre quadros", CommandNamespace.DEVICE_CONFIG, minSdk = 30),
            AndroidCommand("bl_09", ModuleId.BONECO_LENTO, "settings put global debug.hwui.fps_divisor 1", "Mantém divisor nativo 1:1 no pipeline HWUI", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("bl_10", ModuleId.BONECO_LENTO, "settings put global debug.sf.early_phase_offset_ns 500000", "Ajuste fino de fase de VSync para leitura visual limpa", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("bl_11", ModuleId.BONECO_LENTO, "settings put global debug.sf.early_app_phase_offset_ns 500000", "Sincroniza fase de app para movimentação fluida", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("bl_12", ModuleId.BONECO_LENTO, "settings put global debug.sf.early_gl_phase_offset_ns 3000000", "Sincroniza fase GL para quadros previsíveis", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("bl_13", ModuleId.BONECO_LENTO, "settings put global debug.sf.early_gl_app_phase_offset_ns 15000000", "Reduz jitter de quadros durante troca de direção", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("bl_14", ModuleId.BONECO_LENTO, "settings put global debug.egl.swapinterval 1", "Trava intervalo de troca EGL estável", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("bl_15", ModuleId.BONECO_LENTO, "settings put global debug.hwui.disable_vsync false", "Garante VSync ativo sem tearing de frame", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("bl_16", ModuleId.BONECO_LENTO, "settings put system fancy_ime_animations 0", "Desativa animações do teclado em segundo plano", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("bl_17", ModuleId.BONECO_LENTO, "settings put global force_resizable_activities 0", "Evita recálculo de layout em janela fixa", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("bl_18", ModuleId.BONECO_LENTO, "cmd display set-match-content-frame-rate-pref 1", "Alinha cadência de quadros sem quedas bruscas", CommandNamespace.CMD_DISPLAY, minSdk = 31),
            AndroidCommand("bl_19", ModuleId.BONECO_LENTO, "settings put global debug.choreographer.vsync true", "Ativa sincronismo de Coreógrafo no Android", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("bl_20", ModuleId.BONECO_LENTO, if (sdk >= 31) "cmd activity set-process-limit -1" else "settings put global always_finish_activities 0", "Estabiliza retenção do pipeline visual principal", CommandNamespace.CMD_ACTIVITY)
        )
    }

    // 15 comandos reais (usa somente o Hz suportado pelo aparelho)
    private fun buildForceHzCommands(vendor: VendorBrand, sdk: Int, targetHz: Int): List<AndroidCommand> {
        val hzFloat = "${targetHz}.0"
        val vendorHzMode = when (vendor) {
            VendorBrand.SAMSUNG -> "settings put secure refresh_rate_mode 2"
            VendorBrand.XIAOMI -> "settings put system user_refresh_rate $targetHz"
            VendorBrand.MOTOROLA -> "settings put system moto_refresh_rate $targetHz"
            VendorBrand.REALME_OPPO -> "settings put secure coloros_screen_refresh_rate 1"
            VendorBrand.ASUS -> "settings put system rog_refresh_rate $targetHz"
            VendorBrand.GENERIC -> "settings put system display_refresh_rate_mode 1"
        }

        return listOf(
            AndroidCommand("hz_01", ModuleId.FORCE_HZ, "settings put system peak_refresh_rate $hzFloat", "Define taxa de pico em ${targetHz}Hz", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("hz_02", ModuleId.FORCE_HZ, "settings put system min_refresh_rate $hzFloat", "Trava taxa mínima em ${targetHz}Hz", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("hz_03", ModuleId.FORCE_HZ, "settings put system user_refresh_rate $targetHz", "Preferência de usuário fixada em ${targetHz}Hz", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("hz_04", ModuleId.FORCE_HZ, vendorHzMode, "Chave proprietária de taxa de atualização (${vendor.displayName})", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("hz_05", ModuleId.FORCE_HZ, "settings put global peak_refresh_rate $hzFloat", "Reforço global de pico em ${targetHz}Hz", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("hz_06", ModuleId.FORCE_HZ, "settings put global min_refresh_rate $hzFloat", "Reforço global de mínimo em ${targetHz}Hz", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("hz_07", ModuleId.FORCE_HZ, "settings put secure miui_refresh_rate $targetHz", "Taxa de varredura fixa para displays Xiaomi/Poco", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("hz_08", ModuleId.FORCE_HZ, "settings put system max_refresh_rate $hzFloat", "Alinha teto de atualização em ${targetHz}Hz", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("hz_09", ModuleId.FORCE_HZ, "settings put global oneplus_screen_refresh_rate 0", "Desativa redução automática de Hz em repouso", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("hz_10", ModuleId.FORCE_HZ, "cmd device_config put display_manager peak_refresh_rate_default $hzFloat", "Default do DisplayManager para ${targetHz}Hz", CommandNamespace.DEVICE_CONFIG, minSdk = 30),
            AndroidCommand("hz_11", ModuleId.FORCE_HZ, "cmd device_config put surface_flinger_native_boot min_acquired_buffers 2", "Buffers adquiridos para manter ${targetHz}Hz constante", CommandNamespace.DEVICE_CONFIG, minSdk = 30),
            AndroidCommand("hz_12", ModuleId.FORCE_HZ, "settings put global debug.sf.showupdates 0", "Desativa highlight de atualização do compositor", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("hz_13", ModuleId.FORCE_HZ, "settings put global low_power_sticky 0", "Impede queda automática para 60Hz em economia", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("hz_14", ModuleId.FORCE_HZ, "cmd display set-match-content-frame-rate-pref 2", "Prioriza taxa máxima suportada em conteúdo contínuo", CommandNamespace.CMD_DISPLAY, minSdk = 31),
            AndroidCommand("hz_15", ModuleId.FORCE_HZ, if (sdk >= 30) "settings put system thermal_limit_refresh_rate 0" else "settings put system display_color_mode 0", "Evita redução térmica prematura de Hz", CommandNamespace.SETTINGS_SYSTEM)
        )
    }

    // 25 comandos reais
    private fun buildTurboBoostCommands(vendor: VendorBrand, sdk: Int): List<AndroidCommand> {
        val vendorPerf = when (vendor) {
            VendorBrand.SAMSUNG -> "settings put global sem_performance_mode 1"
            VendorBrand.XIAOMI -> "settings put global power_mode_level 3"
            VendorBrand.MOTOROLA -> "settings put global moto_boost_mode 1"
            VendorBrand.REALME_OPPO -> "settings put global high_performance_mode_on 1"
            VendorBrand.ASUS -> "settings put global sys_performance_mode 1"
            VendorBrand.GENERIC -> "settings put global sustained_performance_mode 1"
        }

        return listOf(
            AndroidCommand("tb_01", ModuleId.TURBO_BOOST, "cmd power set-fixed-performance-mode-enabled true", "Ativa modo de performance fixa de CPU/GPU", CommandNamespace.CMD_POWER, minSdk = 30),
            AndroidCommand("tb_02", ModuleId.TURBO_BOOST, "cmd thermalservice override-status 0", "Mantém status térmico nominal sem throttling artificial", CommandNamespace.CMD_THERMAL, minSdk = 29),
            AndroidCommand("tb_03", ModuleId.TURBO_BOOST, vendorPerf, "Perfil de desempenho máximo do fabricante", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("tb_04", ModuleId.TURBO_BOOST, "settings put global debug.hwui.renderer skiagl", "Seleciona backend gráfico SkiaGL para menor overhead", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("tb_05", ModuleId.TURBO_BOOST, "settings put global debug.hwui.render_dirty_regions false", "Otimiza redesenho completo de camadas HWUI", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("tb_06", ModuleId.TURBO_BOOST, "settings put global debug.hwui.profile false", "Desativa coleta de perfil HWUI que consome CPU", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("tb_07", ModuleId.TURBO_BOOST, "settings put global debug.hwui.show_dirty_regions false", "Desativa depuração visual de regiões sujas", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("tb_08", ModuleId.TURBO_BOOST, "settings put global debug.hwui.show_layers_updates false", "Desativa inspeção de atualização de camadas", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("tb_09", ModuleId.TURBO_BOOST, "settings put global debug.sf.hw 1", "Força composição via hardware SurfaceFlinger", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("tb_10", ModuleId.TURBO_BOOST, "settings put global debug.egl.hw 1", "Força aceleração de hardware EGL", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("tb_11", ModuleId.TURBO_BOOST, "settings put global debug.composition.type gpu", "Direciona composição de camadas para a GPU", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("tb_12", ModuleId.TURBO_BOOST, "settings put global debug.performance.tuning 1", "Habilita ajuste fino de desempenho gráfico", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("tb_13", ModuleId.TURBO_BOOST, "settings put global debug.force_gpu_rendering 1", "Força aceleração GPU em componentes 2D", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("tb_14", ModuleId.TURBO_BOOST, "settings put global debug.gl.disable_multisampling 1", "Desativa MSAA forçado para maximizar FPS bruto", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("tb_15", ModuleId.TURBO_BOOST, "cmd device_config put runtime_native use_generational_cc true", "Coletor de lixo geracional mais rápido no ART", CommandNamespace.DEVICE_CONFIG, minSdk = 29),
            AndroidCommand("tb_16", ModuleId.TURBO_BOOST, "cmd device_config put runtime_native usap_pool_enabled true", "Acelera inicialização e alocação de processos", CommandNamespace.DEVICE_CONFIG, minSdk = 29),
            AndroidCommand("tb_17", ModuleId.TURBO_BOOST, "cmd device_config put surface_flinger_native_boot max_frame_buffer_acquired_buffers 3", "Triplo buffering otimizado para fluidez contínua", CommandNamespace.DEVICE_CONFIG, minSdk = 30),
            AndroidCommand("tb_18", ModuleId.TURBO_BOOST, "settings put global wifi_power_save 0", "Desativa economia de energia no chip Wi-Fi (menor ping)", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("tb_19", ModuleId.TURBO_BOOST, "settings put global wifi_sleep_policy 2", "Mantém rádio Wi-Fi sempre em alta potência", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("tb_20", ModuleId.TURBO_BOOST, "settings put global mobile_data_always_on 0", "Evita concorrência de rádio móvel durante Wi-Fi", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("tb_21", ModuleId.TURBO_BOOST, "settings put global network_avoid_bad_wifi 0", "Evita troca abrupta de rede no meio da partida", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("tb_22", ModuleId.TURBO_BOOST, "cmd activity kill-all", "Encerra processos em cache que competem por CPU", CommandNamespace.CMD_ACTIVITY),
            AndroidCommand("tb_23", ModuleId.TURBO_BOOST, "cmd power set-mode 0", "Garante modo de energia desbloqueado", CommandNamespace.CMD_POWER, minSdk = 29),
            AndroidCommand("tb_24", ModuleId.TURBO_BOOST, "settings put global ram_expand_size 0", "Evita swap lento em disco durante pico de GPU", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("tb_25", ModuleId.TURBO_BOOST, if (sdk >= 31) "cmd activity memory-factor set NORMAL" else "am send-trim-memory com.dts.freefireth COMPLETE", "Normaliza fator de pressão de memória do sistema", CommandNamespace.CMD_ACTIVITY)
        )
    }

    // 20 comandos reais
    private fun buildLockFpsCommands(vendor: VendorBrand, sdk: Int): List<AndroidCommand> {
        val vendorGame = when (vendor) {
            VendorBrand.SAMSUNG -> "settings put secure game_booster_fps_limit 0"
            VendorBrand.XIAOMI -> "settings put global game_turbo_fps_lock 100"
            else -> "settings put global game_fps_stability 1"
        }

        return listOf(
            AndroidCommand("fps_01", ModuleId.LOCK_FPS, "cmd device_config put game_manager com.dts.freefireth mode=2,fps=90:mode=3,fps=60", "GameManager: perfil Performance 90+ FPS para FF Normal", CommandNamespace.DEVICE_CONFIG, minSdk = 31),
            AndroidCommand("fps_02", ModuleId.LOCK_FPS, "cmd device_config put game_manager com.dts.freefiremax mode=2,fps=90:mode=3,fps=60", "GameManager: perfil Performance 90+ FPS para FF MAX", CommandNamespace.DEVICE_CONFIG, minSdk = 31),
            AndroidCommand("fps_03", ModuleId.LOCK_FPS, "cmd game mode performance com.dts.freefireth", "Ativa modo Game Performance para Free Fire Normal", CommandNamespace.CMD_GAME, minSdk = 31),
            AndroidCommand("fps_04", ModuleId.LOCK_FPS, "cmd game mode performance com.dts.freefiremax", "Ativa modo Game Performance para Free Fire MAX", CommandNamespace.CMD_GAME, minSdk = 31),
            AndroidCommand("fps_05", ModuleId.LOCK_FPS, vendorGame, "Desbloqueia limitador de FPS do game booster nativo", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("fps_06", ModuleId.LOCK_FPS, "cmd device_config put game_overlay com.dts.freefireth mode=2,downscaleFactor=0.9,useAngle=false,fps=90", "Configura overlay de driver GameOverlay em 90-100 FPS", CommandNamespace.DEVICE_CONFIG, minSdk = 31),
            AndroidCommand("fps_07", ModuleId.LOCK_FPS, "cmd device_config put game_overlay com.dts.freefiremax mode=2,downscaleFactor=0.9,useAngle=false,fps=90", "Configura overlay de driver FF MAX para alta taxa", CommandNamespace.DEVICE_CONFIG, minSdk = 31),
            AndroidCommand("fps_08", ModuleId.LOCK_FPS, "cmd thermalservice override-status 0", "Impede queda de clock por sensor térmico moderado", CommandNamespace.CMD_THERMAL, minSdk = 29),
            AndroidCommand("fps_09", ModuleId.LOCK_FPS, "settings put global debug.sf.frame_rate_multiple_threshold 90", "Ajusta limiar múltiplo de taxa de quadros", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("fps_10", ModuleId.LOCK_FPS, "settings put global debug.hwui.target_cpu_time_percent 95", "Aloca até 95% de orçamento de frame para renderização", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("fps_11", ModuleId.LOCK_FPS, "settings put global debug.hwui.target_gpu_time_percent 95", "Prioriza fila de GPU para evitar drop de FPS", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("fps_12", ModuleId.LOCK_FPS, "settings put global debug.gralloc.gfx_ubwc_disable 0", "Mantém compressão UBWC ativa para banda de memória GPU", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("fps_13", ModuleId.LOCK_FPS, "settings put global debug.cpurend.vsync false", "Evita bloqueio de CPU aguardando VSync secundário", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("fps_14", ModuleId.LOCK_FPS, "settings put global debug.gpurend.vsync false", "Reduz espera de pipeline de GPU", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("fps_15", ModuleId.LOCK_FPS, "cmd power set-adaptive-power-saver-enabled false", "Bloqueia queda automática de clock durante trocação", CommandNamespace.CMD_POWER, minSdk = 29),
            AndroidCommand("fps_16", ModuleId.LOCK_FPS, "settings put global app_standby_enabled 1", "Mantém apps ociosos contidos fora da memória ativa", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("fps_17", ModuleId.LOCK_FPS, "settings put global zram_enabled 0", "Evita compressão de RAM com alto custo de CPU", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("fps_18", ModuleId.LOCK_FPS, "cmd device_config put activity_manager max_cached_processes 16", "Limita processos em cache para preservar RAM livre", CommandNamespace.DEVICE_CONFIG, minSdk = 29),
            AndroidCommand("fps_19", ModuleId.LOCK_FPS, "cmd device_config put activity_manager bg_auto_restrict_abusive_apps true", "Restringe apps em segundo plano que drenam FPS", CommandNamespace.DEVICE_CONFIG, minSdk = 29),
            AndroidCommand("fps_20", ModuleId.LOCK_FPS, if (sdk >= 31) "cmd game set --fps 90 com.dts.freefireth" else "am broadcast -a android.intent.action.CLOSE_SYSTEM_DIALOGS", "Fixa meta de FPS estável no sistema", CommandNamespace.CMD_GAME)
        )
    }

    // 20 comandos reais
    private fun buildLightUiCommands(vendor: VendorBrand, sdk: Int): List<AndroidCommand> {
        val vendorClean = when (vendor) {
            VendorBrand.XIAOMI -> "settings put global miui_home_animation_rate 0"
            VendorBrand.SAMSUNG -> "settings put system notification_light_pulse 0"
            else -> "settings put secure screensaver_enabled 0"
        }

        return listOf(
            AndroidCommand("ui_01", ModuleId.LIGHT_UI, "pm trim-caches 512M", "Limpa até 512MB de caches temporários de pacotes", CommandNamespace.PM),
            AndroidCommand("ui_02", ModuleId.LIGHT_UI, "am kill-all", "Encerra processos em segundo plano dispensáveis", CommandNamespace.AM),
            AndroidCommand("ui_03", ModuleId.LIGHT_UI, "cmd activity idle-maintenance", "Executa manutenção leve de memória no sistema", CommandNamespace.CMD_ACTIVITY),
            AndroidCommand("ui_04", ModuleId.LIGHT_UI, "settings put global cached_apps_freezer enabled", "Congela aplicativos em segundo plano sem consumo de CPU", CommandNamespace.SETTINGS_GLOBAL, minSdk = 30),
            AndroidCommand("ui_05", ModuleId.LIGHT_UI, "settings put global sysui_tuner_demo_on 0", "Mantém SystemUI limpa sem serviços de demo", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("ui_06", ModuleId.LIGHT_UI, "settings put secure show_ime_with_hard_keyboard 0", "Evita popup desnecessário de teclado", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("ui_07", ModuleId.LIGHT_UI, vendorClean, "Desativa efeitos pesados de SystemUI do fabricante", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("ui_08", ModuleId.LIGHT_UI, "settings put global fancy_ime_animations 0", "Remove animação pesada de abertura de teclado", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("ui_09", ModuleId.LIGHT_UI, "settings put secure accessibility_display_inversion_enabled 0", "Garante ausência de filtro de inversão por GPU", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("ui_10", ModuleId.LIGHT_UI, "settings put secure accessibility_display_daltonizer_enabled 0", "Desativa shader extra de daltonismo na composição", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("ui_11", ModuleId.LIGHT_UI, "settings put global send_action_app_error 0", "Desativa telemetria pesada de relatório de erro", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("ui_12", ModuleId.LIGHT_UI, "settings put global anr_show_background 0", "Evita diálogos de ANR de apps secundários", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("ui_13", ModuleId.LIGHT_UI, "settings put global dropbox_max_files 10", "Limita logs de diagnóstico acumulados em disco", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("ui_14", ModuleId.LIGHT_UI, "settings put secure location_providers_allowed -network", "Reduz wakeups contínuos de localização de rede", CommandNamespace.SETTINGS_SECURE),
            AndroidCommand("ui_15", ModuleId.LIGHT_UI, "settings put global auto_sync 0", "Pausa sincronização pesada em segundo plano", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("ui_16", ModuleId.LIGHT_UI, "settings put system sound_effects_enabled 0", "Desativa áudio extra de cliques de interface do sistema", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("ui_17", ModuleId.LIGHT_UI, "settings put system lockscreen_sounds_enabled 0", "Libera mixer de áudio para canais do jogo", CommandNamespace.SETTINGS_SYSTEM),
            AndroidCommand("ui_18", ModuleId.LIGHT_UI, "settings put global upload_log_pref 0", "Desativa envio de logs em background", CommandNamespace.SETTINGS_GLOBAL),
            AndroidCommand("ui_19", ModuleId.LIGHT_UI, "cmd device_config put activity_manager default_background_activity_starts_enabled false", "Bloqueia inicialização silenciosa de apps em segundo plano", CommandNamespace.DEVICE_CONFIG, minSdk = 29),
            AndroidCommand("ui_20", ModuleId.LIGHT_UI, if (sdk >= 30) "pm trim-caches 1024M internal" else "pm trim-caches 512M", "Liberação adicional de cache interno antes de abrir o jogo", CommandNamespace.PM)
        )
    }
}
