package com.raylan.fangx.engine

import androidx.annotation.Keep
import java.security.MessageDigest

@Retention(AnnotationRetention.RUNTIME)
@Target(AnnotationTarget.FUNCTION)
annotation class ModuleSignature(val token: String)

/**
 * Núcleo de assinaturas das funções principais do Fangx.
 * Protegido em tempo real pelo SecurityGuard contra renomeação via MT Manager / NP Manager.
 */
@Keep
object CoreModuleSignatures {

    private const val EXPECTED_DIGEST =
        "Fangx|com.raylan.fangx|Aimbot|Aimlock|No Recoil|No Recoil 2|Aimbot 2x|HS 75%|Boneco Lento"

    @Keep
    @ModuleSignature("Aimbot")
    fun Aimbot(sensitivityScale: Int = 7): String = "Aimbot:pointer_speed=$sensitivityScale"

    @Keep
    @ModuleSignature("Aimlock")
    fun Aimlock(axisLock: Boolean = true): String = "Aimlock:linear_xy=$axisLock"

    @Keep
    @ModuleSignature("No Recoil")
    fun NoRecoil(verticalDamping: Float = 0.0f): String = "No Recoil:anim_scale=$verticalDamping"

    @Keep
    @ModuleSignature("No Recoil 2")
    fun NoRecoil2(multiTouchBuffer: Int = 1): String = "No Recoil 2:buffer=$multiTouchBuffer"

    @Keep
    @ModuleSignature("Aimbot 2x")
    fun Aimbot2x(scopePrecision: Int = 2): String = "Aimbot 2x:scope=$scopePrecision"

    @Keep
    @ModuleSignature("HS 75%")
    fun Hs75(verticalBoost: Boolean = true): String = "HS 75%:boost=$verticalBoost"

    @Keep
    @ModuleSignature("Boneco Lento")
    fun BonecoLento(framePacing: Float = 0.0f): String = "Boneco Lento:pacing=$framePacing"

    fun requiredTokens(): List<String> = listOf(
        "Aimbot",
        "Aimlock",
        "No Recoil",
        "No Recoil 2",
        "Aimbot 2x",
        "HS 75%",
        "Boneco Lento"
    )

    fun computeIntegrityDigest(): String {
        val raw = buildString {
            append("Fangx|")
            append("com.raylan.fangx|")
            append(requiredTokens().joinToString("|"))
        }
        val digest = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun expectedDigestHash(): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(EXPECTED_DIGEST.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }
}
