package com.raylan.fangx.ui.theme

import androidx.compose.ui.graphics.Color

val FangxBg = Color(0xFF0D0F14)
val FangxSurface = Color(0xFF161A23)
val FangxSurfaceElevated = Color(0xFF1E2430)
val FangxBorder = Color(0xFF283040)

val FangxCyan = Color(0xFF00F0FF)
val FangxCyanDim = Color(0xFF00A8B5)
val FangxRed = Color(0xFFFF2A54)
val FangxRedDim = Color(0xFFB31939)
val FangxGreen = Color(0xFF00E676)
val FangxAmber = Color(0xFFFFB300)

val FangxTextPrimary = Color(0xFFF2F5FA)
val FangxTextSecondary = Color(0xFF94A3B8)
val FangxTextMuted = Color(0xFF64748B)

val FangxSecurityBg = Color(0xFF1A050A)
val FangxSecurityBorder = Color(0xFF660F24)
