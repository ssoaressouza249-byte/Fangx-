package com.raylan.fangx.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CenterFocusStrong
import androidx.compose.material.icons.rounded.DisplaySettings
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.raylan.fangx.model.CrosshairColorOption
import com.raylan.fangx.model.CrosshairConfig
import com.raylan.fangx.model.CrosshairShape
import com.raylan.fangx.model.DeviceProfile
import com.raylan.fangx.model.GeneratedSensiRecommendation
import com.raylan.fangx.model.SensitivityProfile
import com.raylan.fangx.ui.theme.FangxAmber
import com.raylan.fangx.ui.theme.FangxBg
import com.raylan.fangx.ui.theme.FangxBorder
import com.raylan.fangx.ui.theme.FangxCyan
import com.raylan.fangx.ui.theme.FangxGreen
import com.raylan.fangx.ui.theme.FangxRed
import com.raylan.fangx.ui.theme.FangxSurface
import com.raylan.fangx.ui.theme.FangxSurfaceElevated
import com.raylan.fangx.ui.theme.FangxTextPrimary
import com.raylan.fangx.ui.theme.FangxTextSecondary
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SensiScreen(
    crosshairConfig: CrosshairConfig,
    hasOverlayPermission: Boolean,
    sensitivity: SensitivityProfile,
    generatedRecommendation: GeneratedSensiRecommendation?,
    deviceProfile: DeviceProfile,
    dpiInput: Int,
    dpiStatusMessage: String?,
    onToggleOverlay: () -> Boolean,
    onOpenOverlaySettings: () -> Unit,
    onUpdateShape: (CrosshairShape) -> Unit,
    onUpdateColor: (CrosshairColorOption) -> Unit,
    onUpdateSize: (Float) -> Unit,
    onUpdateOpacity: (Float) -> Unit,
    onUpdateSensitivity: (geral: Int, redDot: Int, scope2x: Int, scope4x: Int, awm: Int, olhadinha: Int) -> Unit,
    onGeneratePerfectSensi: () -> Unit,
    onUpdateDpiInput: (Int) -> Unit,
    onApplyDpi: () -> Unit,
    onRestoreDefaultDpi: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        onToggleOverlay()
    }

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .fillMaxSize()
            .testTag("screen_sensi")
    ) {
        // 1. MIRA FLUTUANTE CUSTOMIZADA
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = FangxSurface,
                border = BorderStroke(1.dp, if (crosshairConfig.enabled) FangxCyan else FangxBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 640.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CenterFocusStrong,
                                contentDescription = null,
                                tint = FangxCyan,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "MIRA FLUTUANTE CUSTOMIZADA",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = FangxTextPrimary
                                )
                                Text(
                                    text = if (hasOverlayPermission) "Sobreposição liberada" else "Requer permissão SYSTEM_ALERT_WINDOW",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (hasOverlayPermission) FangxGreen else FangxAmber
                                )
                            }
                        }

                        Switch(
                            checked = crosshairConfig.enabled,
                            onCheckedChange = {
                                if (!hasOverlayPermission) {
                                    onOpenOverlaySettings()
                                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                                    ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.POST_NOTIFICATIONS
                                    ) != PackageManager.PERMISSION_GRANTED
                                ) {
                                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    onToggleOverlay()
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = FangxBg,
                                checkedTrackColor = FangxCyan,
                                uncheckedThumbColor = FangxTextSecondary,
                                uncheckedTrackColor = FangxSurfaceElevated
                            ),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("crosshair_overlay_switch")
                        )
                    }

                    if (!hasOverlayPermission) {
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = onOpenOverlaySettings,
                            border = BorderStroke(1.dp, FangxAmber),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("grant_overlay_permission_button")
                        ) {
                            Text(
                                text = "PERMITIR SOBREPOR OUTROS APPS",
                                style = MaterialTheme.typography.labelMedium,
                                color = FangxAmber
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Preview da Mira
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = FangxBg,
                        border = BorderStroke(1.dp, FangxBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            CrosshairPreviewCanvas(config = crosshairConfig)
                            Text(
                                text = "PREVIEW AO VIVO",
                                style = MaterialTheme.typography.labelSmall,
                                color = FangxTextSecondary.copy(alpha = 0.5f),
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(8.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "FORMATO",
                        style = MaterialTheme.typography.labelSmall,
                        color = FangxTextSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CrosshairShape.entries.forEach { shape ->
                            val selected = crosshairConfig.shape == shape
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (selected) FangxCyan.copy(alpha = 0.16f) else FangxSurfaceElevated,
                                border = BorderStroke(1.dp, if (selected) FangxCyan else FangxBorder),
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .clickable { onUpdateShape(shape) }
                                    .testTag("shape_${shape.name.lowercase()}")
                            ) {
                                Text(
                                    text = shape.label,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (selected) FangxCyan else FangxTextPrimary,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "COR DA MIRA",
                        style = MaterialTheme.typography.labelSmall,
                        color = FangxTextSecondary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        CrosshairColorOption.entries.forEach { option ->
                            val selected = crosshairConfig.colorOption == option
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(if (selected) option.composeColor.copy(alpha = 0.2f) else FangxSurfaceElevated)
                                    .clickable { onUpdateColor(option) }
                                    .testTag("color_${option.name.lowercase()}")
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(option.composeColor)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LabeledSliderRow(
                        label = "Tamanho",
                        valueText = "${crosshairConfig.sizeDp.roundToInt()} dp",
                        value = crosshairConfig.sizeDp,
                        range = 16f..72f,
                        accent = FangxCyan,
                        onValueChange = onUpdateSize
                    )

                    LabeledSliderRow(
                        label = "Opacidade",
                        valueText = "${(crosshairConfig.opacity * 100).roundToInt()}%",
                        value = crosshairConfig.opacity,
                        range = 0.2f..1.0f,
                        accent = FangxCyan,
                        onValueChange = onUpdateOpacity
                    )
                }
            }
        }

        // 2. GERADOR DE SENSI INFINITA (100 A 200)
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = FangxSurface,
                border = BorderStroke(1.dp, FangxBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 640.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Tune,
                            contentDescription = null,
                            tint = FangxRed,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "GERADOR DE SENSI INFINITA (100 - 200)",
                                style = MaterialTheme.typography.titleMedium,
                                color = FangxTextPrimary
                            )
                            Text(
                                text = "Calibração estendida para capa rápido no ${deviceProfile.model}",
                                style = MaterialTheme.typography.labelSmall,
                                color = FangxTextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    SensiSlider("Geral", sensitivity.geral, FangxCyan) {
                        onUpdateSensitivity(it, sensitivity.redDot, sensitivity.scope2x, sensitivity.scope4x, sensitivity.awm, sensitivity.olhadinha)
                    }
                    SensiSlider("Ponto Vermelho", sensitivity.redDot, FangxRed) {
                        onUpdateSensitivity(sensitivity.geral, it, sensitivity.scope2x, sensitivity.scope4x, sensitivity.awm, sensitivity.olhadinha)
                    }
                    SensiSlider("Mira 2x", sensitivity.scope2x, FangxCyan) {
                        onUpdateSensitivity(sensitivity.geral, sensitivity.redDot, it, sensitivity.scope4x, sensitivity.awm, sensitivity.olhadinha)
                    }
                    SensiSlider("Mira 4x", sensitivity.scope4x, FangxRed) {
                        onUpdateSensitivity(sensitivity.geral, sensitivity.redDot, sensitivity.scope2x, it, sensitivity.awm, sensitivity.olhadinha)
                    }
                    SensiSlider("AWM", sensitivity.awm, FangxCyan) {
                        onUpdateSensitivity(sensitivity.geral, sensitivity.redDot, sensitivity.scope2x, sensitivity.scope4x, it, sensitivity.olhadinha)
                    }
                    SensiSlider("Olhadinha", sensitivity.olhadinha, FangxRed) {
                        onUpdateSensitivity(sensitivity.geral, sensitivity.redDot, sensitivity.scope2x, sensitivity.scope4x, sensitivity.awm, it)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onGeneratePerfectSensi,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = FangxCyan,
                            contentColor = FangxBg
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("generate_perfect_sensi_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AutoAwesome,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "GERAR SENSI PERFEITA PARA MEU CELULAR",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Black)
                        )
                    }

                    if (generatedRecommendation != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = FangxBg,
                            border = BorderStroke(1.dp, FangxCyan.copy(alpha = 0.6f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("generated_sensi_card")
                        ) {
                            Column(
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.padding(12.dp)
                            ) {
                                Text(
                                    text = generatedRecommendation.deviceSummary,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = FangxCyan
                                )
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    MetricPill(
                                        title = "DPI IDEAL",
                                        value = "${generatedRecommendation.idealDpi}",
                                        accent = FangxCyan,
                                        modifier = Modifier.weight(1f)
                                    )
                                    MetricPill(
                                        title = "BOTÃO ATIRAR",
                                        value = "${generatedRecommendation.fireButtonSizePercent}%",
                                        accent = FangxRed,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                Text(
                                    text = "Dica de Puxada: ${generatedRecommendation.dragTip}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = FangxTextPrimary
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. AJUSTE DE DPI VIA SHIZUKU (wm density)
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = FangxSurface,
                border = BorderStroke(1.dp, FangxBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 640.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.DisplaySettings,
                            contentDescription = null,
                            tint = FangxCyan,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "RESOLUÇÃO & DPI VIA SHIZUKU",
                                style = MaterialTheme.typography.titleMedium,
                                color = FangxTextPrimary
                            )
                            Text(
                                text = "Atual: ${deviceProfile.currentDpi} dpi • Padrão de fábrica: ${deviceProfile.defaultDpi} dpi",
                                style = MaterialTheme.typography.labelSmall,
                                color = FangxTextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LabeledSliderRow(
                        label = "DPI Alvo (wm density)",
                        valueText = "$dpiInput dpi",
                        value = dpiInput.toFloat(),
                        range = 320f..860f,
                        accent = FangxCyan,
                        onValueChange = { onUpdateDpiInput(it.roundToInt()) }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = onApplyDpi,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = FangxSurfaceElevated,
                                contentColor = FangxCyan
                            ),
                            border = BorderStroke(1.dp, FangxCyan),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("apply_dpi_button")
                        ) {
                            Text(
                                text = "APLICAR DPI ($dpiInput)",
                                style = MaterialTheme.typography.labelMedium
                            )
                        }

                        Button(
                            onClick = onRestoreDefaultDpi,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = FangxRed.copy(alpha = 0.18f),
                                contentColor = FangxRed
                            ),
                            border = BorderStroke(1.dp, FangxRed),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("restore_default_dpi_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Restore,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "RESTAURAR DPI PADRÃO",
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1
                            )
                        }
                    }

                    if (dpiStatusMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = dpiStatusMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = FangxGreen
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CrosshairPreviewCanvas(config: CrosshairConfig) {
    Canvas(modifier = Modifier.size(90.dp)) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val radius = (config.sizeDp / 72f) * (size.minDimension * 0.44f) + 6f
        val color = config.colorOption.composeColor.copy(alpha = config.opacity)
        val stroke = 4.5f
        val gap = radius * 0.28f

        when (config.shape) {
            CrosshairShape.DOT -> {
                drawCircle(color = color, radius = (radius * 0.25f).coerceAtLeast(5f), center = Offset(cx, cy))
            }
            CrosshairShape.CROSS -> {
                drawLine(color, Offset(cx - radius, cy), Offset(cx - gap, cy), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx + gap, cy), Offset(cx + radius, cy), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx, cy - radius), Offset(cx, cy - gap), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx, cy + gap), Offset(cx, cy + radius), strokeWidth = stroke, cap = StrokeCap.Round)
                drawCircle(color = color, radius = 3.5f, center = Offset(cx, cy))
            }
            CrosshairShape.CIRCLE_CROSS -> {
                drawCircle(
                    color = color,
                    radius = radius * 0.65f,
                    center = Offset(cx, cy),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke)
                )
                drawLine(color, Offset(cx - radius, cy), Offset(cx - gap, cy), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx + gap, cy), Offset(cx + radius, cy), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx, cy - radius), Offset(cx, cy - gap), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx, cy + gap), Offset(cx, cy + radius), strokeWidth = stroke, cap = StrokeCap.Round)
                drawCircle(color = color, radius = 3.5f, center = Offset(cx, cy))
            }
            CrosshairShape.DIAMOND -> {
                val r = radius * 0.78f
                drawLine(color, Offset(cx, cy - r), Offset(cx + r, cy), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx + r, cy), Offset(cx, cy + r), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx, cy + r), Offset(cx - r, cy), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx - r, cy), Offset(cx, cy - r), strokeWidth = stroke, cap = StrokeCap.Round)
                drawCircle(color = color, radius = 4f, center = Offset(cx, cy))
            }
            CrosshairShape.TACTICAL_X -> {
                val arm = radius * 0.75f
                val inner = radius * 0.22f
                drawLine(color, Offset(cx - arm, cy - arm), Offset(cx - inner, cy - inner), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx + inner, cy - inner), Offset(cx + arm, cy - arm), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx - arm, cy + arm), Offset(cx - inner, cy + inner), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx + inner, cy + inner), Offset(cx + arm, cy + arm), strokeWidth = stroke, cap = StrokeCap.Round)
                drawCircle(color = color, radius = 3.5f, center = Offset(cx, cy))
            }
        }
    }
}

@Composable
private fun SensiSlider(
    title: String,
    value: Int,
    accent: Color,
    onValueChange: (Int) -> Unit
) {
    LabeledSliderRow(
        label = title,
        valueText = value.toString(),
        value = value.toFloat(),
        range = 100f..200f,
        accent = accent,
        onValueChange = { onValueChange(it.roundToInt()) }
    )
}

@Composable
private fun LabeledSliderRow(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    accent: Color,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = FangxTextPrimary
            )
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = FangxSurfaceElevated,
                border = BorderStroke(1.dp, accent.copy(alpha = 0.5f))
            ) {
                Text(
                    text = valueText,
                    style = MaterialTheme.typography.labelMedium,
                    color = accent,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = accent,
                activeTrackColor = accent,
                inactiveTrackColor = FangxSurfaceElevated
            ),
            modifier = Modifier.testTag("slider_${label.lowercase().replace(" ", "_")}")
        )
    }
}

@Composable
private fun MetricPill(
    title: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = FangxSurfaceElevated,
        border = BorderStroke(1.dp, FangxBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text(text = title, style = MaterialTheme.typography.labelSmall, color = FangxTextSecondary)
            Text(text = value, style = MaterialTheme.typography.titleMedium, color = accent)
        }
    }
}
