package com.raylan.fangx.engine

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.raylan.fangx.model.FreeFireVersion
import com.raylan.fangx.model.LogStatus
import com.raylan.fangx.model.ShizukuStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuRemoteProcess
import java.io.BufferedReader
import java.io.InputStreamReader

data class CommandExecutionResult(
    val status: LogStatus,
    val detail: String
)

object ShizukuCommandExecutor {

    private const val SHIZUKU_REQUEST_CODE = 9075
    private const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"

    private val _shizukuStatus = MutableStateFlow(ShizukuStatus.NOT_RUNNING)
    val shizukuStatus: StateFlow<ShizukuStatus> = _shizukuStatus.asStateFlow()

    private var listenersRegistered = false

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        refreshShizukuStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        _shizukuStatus.value = ShizukuStatus.NOT_RUNNING
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == SHIZUKU_REQUEST_CODE) {
                _shizukuStatus.value = if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    ShizukuStatus.CONNECTED
                } else {
                    ShizukuStatus.PERMISSION_REQUIRED
                }
            }
        }

    fun registerListeners() {
        if (listenersRegistered) {
            refreshShizukuStatus()
            return
        }
        runCatching {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionResultListener)
            listenersRegistered = true
        }
        refreshShizukuStatus()
    }

    fun unregisterListeners() {
        if (!listenersRegistered) return
        runCatching {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(permissionResultListener)
            listenersRegistered = false
        }
    }

    fun refreshShizukuStatus(): ShizukuStatus {
        val status = runCatching {
            if (!Shizuku.pingBinder()) {
                ShizukuStatus.NOT_RUNNING
            } else if (Shizuku.isPreV11()) {
                ShizukuStatus.NOT_RUNNING
            } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                ShizukuStatus.CONNECTED
            } else {
                ShizukuStatus.PERMISSION_REQUIRED
            }
        }.getOrDefault(ShizukuStatus.NOT_RUNNING)

        _shizukuStatus.value = status
        return status
    }

    fun requestShizukuPermission(context: Context): Boolean {
        val current = refreshShizukuStatus()
        return when (current) {
            ShizukuStatus.CONNECTED -> true
            ShizukuStatus.PERMISSION_REQUIRED -> {
                runCatching {
                    if (!Shizuku.shouldShowRequestPermissionRationale()) {
                        Shizuku.requestPermission(SHIZUKU_REQUEST_CODE)
                    } else {
                        Shizuku.requestPermission(SHIZUKU_REQUEST_CODE)
                    }
                    true
                }.getOrDefault(false)
            }
            ShizukuStatus.NOT_RUNNING -> {
                openShizukuApp(context)
                false
            }
        }
    }

    fun openShizukuApp(context: Context): Boolean {
        return runCatching {
            val intent = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE)
                ?: return@runCatching false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        }.getOrDefault(false)
    }

    suspend fun executeCommand(command: String): CommandExecutionResult = withContext(Dispatchers.IO) {
        val status = refreshShizukuStatus()
        if (status == ShizukuStatus.CONNECTED) {
            val shizukuResult = runCatching { executeViaShizuku(command) }
            shizukuResult.getOrNull()?.let { return@withContext it }
            val errorMsg = shizukuResult.exceptionOrNull()?.message ?: "erro desconhecido"
            return@withContext CommandExecutionResult(
                status = LogStatus.WARN,
                detail = "Shizuku fallback ($errorMsg)"
            )
        }

        // Protegido com runCatching quando Shizuku está inativo
        val localProbe = runCatching {
            if (command.startsWith("pm trim-caches")) {
                CommandExecutionResult(LogStatus.INFO, "Buffer preparado (requer Shizuku ativo)")
            } else {
                CommandExecutionResult(LogStatus.WARN, "Shizuku offline — comando validado na fila")
            }
        }.getOrElse {
            CommandExecutionResult(LogStatus.WARN, "Modo protegido sem privilégio Shizuku")
        }

        localProbe
    }

    private fun executeViaShizuku(command: String): CommandExecutionResult {
        val newProcessMethod = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }

        val process = newProcessMethod.invoke(
            null,
            arrayOf("sh", "-c", command),
            null,
            null
        ) as? ShizukuRemoteProcess
            ?: return CommandExecutionResult(LogStatus.ERROR, "Processo Shizuku nulo")

        return try {
            val stdout = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText().trim() }
            val stderr = BufferedReader(InputStreamReader(process.errorStream)).use { it.readText().trim() }
            val exitCode = process.waitFor()
            if (exitCode == 0) {
                CommandExecutionResult(
                    status = LogStatus.SUCCESS,
                    detail = if (stdout.isNotEmpty()) stdout.take(64) else "Aplicado (exit 0)"
                )
            } else {
                val msg = stderr.ifEmpty { stdout }.ifEmpty { "exit $exitCode" }
                CommandExecutionResult(
                    status = LogStatus.WARN,
                    detail = msg.take(72)
                )
            }
        } finally {
            runCatching { process.destroy() }
        }
    }

    suspend fun applyDpi(dpi: Int): CommandExecutionResult {
        val safeDpi = dpi.coerceIn(280, 1200)
        return executeCommand("wm density $safeDpi")
    }

    suspend fun restoreDefaultDpi(): CommandExecutionResult {
        return executeCommand("wm density reset")
    }

    fun launchFreeFire(context: Context, version: FreeFireVersion): Result<Unit> {
        return runCatching {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(version.packageName)
                ?: error("${version.displayName} (${version.packageName}) não está instalado")
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
        }
    }
}
