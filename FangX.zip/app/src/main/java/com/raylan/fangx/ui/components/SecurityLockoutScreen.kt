package com.raylan.fangx.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GppBad
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.fangx.security.SecurityGuard
import com.raylan.fangx.ui.theme.FangxRed
import com.raylan.fangx.ui.theme.FangxSecurityBg
import com.raylan.fangx.ui.theme.FangxSecurityBorder
import com.raylan.fangx.ui.theme.FangxTextPrimary
import com.raylan.fangx.ui.theme.FangxTextSecondary

@Composable
fun SecurityLockoutScreen(
    technicalDetail: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Bloqueia botão voltar de forma irremovível
    BackHandler(enabled = true) {}

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        FangxSecurityBg,
                        FangxSecurityBg.copy(alpha = 0.96f),
                        FangxSecurityBg
                    )
                )
            )
            .systemBarsPadding()
            .padding(24.dp)
            .testTag("security_lockout_screen"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 520.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                shape = CircleShape,
                color = FangxRed.copy(alpha = 0.16f),
                border = BorderStroke(2.dp, FangxRed),
                modifier = Modifier.size(92.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.GppBad,
                        contentDescription = "Alerta de modificação detectada",
                        tint = FangxRed,
                        modifier = Modifier.size(50.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "PROTEÇÃO ANTI-MODIFICAÇÃO",
                style = MaterialTheme.typography.labelLarge.copy(
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.6.sp
                ),
                color = FangxRed,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(12.dp))

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = FangxRed.copy(alpha = 0.10f),
                border = BorderStroke(1.5.dp, FangxSecurityBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Warning,
                        contentDescription = "Aviso crítico",
                        tint = FangxRed,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = SecurityGuard.LOCKOUT_MESSAGE,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            lineHeight = 23.sp
                        ),
                        color = FangxTextPrimary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.testTag("security_lockout_message")
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = FangxSecurityBg,
                border = BorderStroke(1.dp, FangxSecurityBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "DETALHE TÉCNICO DETECTADO",
                        style = MaterialTheme.typography.labelSmall,
                        color = FangxTextSecondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = technicalDetail,
                        style = MaterialTheme.typography.bodySmall,
                        color = FangxRed,
                        modifier = Modifier.testTag("security_technical_detail")
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            Button(
                onClick = {
                    runCatching {
                        context.startActivity(SecurityGuard.buildUninstallIntent(context))
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = FangxRed,
                    contentColor = FangxTextPrimary
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .testTag("uninstall_tampered_app_button")
            ) {
                Text(
                    text = "DESINSTALAR APP AGORA",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp
                    )
                )
            }
        }
    }
}
