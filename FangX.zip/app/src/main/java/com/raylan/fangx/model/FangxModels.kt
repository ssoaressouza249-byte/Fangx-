package com.raylan.fangx.model

import androidx.compose.ui.graphics.Color
import com.raylan.fangx.ui.theme.FangxCyan
import com.raylan.fangx.ui.theme.FangxGreen
import com.raylan.fangx.ui.theme.FangxRed

enum class VendorBrand(val displayName: String) {
    SAMSUNG("Samsung"),
    XIAOMI("Xiaomi / Poco / Redmi"),
    MOTOROLA("Motorola"),
    REALME_OPPO("Realme / Oppo"),
    ASUS("Asus ROG / Zenfone"),
    GENERIC("Genérico Android")
}

enum class ModuleCategory {
    MIRA,
    PERFORMANCE
}

enum class CommandNamespace(val label: String) {
    SETTINGS_SYSTEM("settings system"),
    SETTINGS_SECURE("settings secure"),
    SETTINGS_GLOBAL("settings global"),
    DEVICE_CONFIG("cmd device_config"),
    CMD_ACTIVITY("cmd activity"),
    CMD_POWER("cmd power"),
    CMD_DISPLAY("cmd display"),
    CMD_THERMAL("cmd thermalservice"),
    CMD_GAME("cmd game"),
    AM("am"),
    PM("pm"),
    WM("wm")
}

enum class ModuleId(val displayTitle: String, val signatureToken: String) {
    AIMBOT("Aimbot", "Aimbot"),
    AIMLOCK("Aimlock", "Aimlock"),
    NO_RECOIL("No Recoil", "No Recoil"),
    NO_RECOIL_2("No Recoil 2", "No Recoil 2"),
    AIMBOT_2X("Aimbot 2x", "Aimbot 2x"),
    HS_75("HS 75%", "HS 75%"),
    BONECO_LENTO("Modo Boneco Lento", "Boneco Lento"),
    FORCE_HZ("Forçar Hz (90Hz / 120Hz / 144Hz)", "ForcarHz"),
    TURBO_BOOST("Turbo Boost CPU & GPU", "TurboBoost"),
    LOCK_FPS("Cravar FPS (90 - 100 FPS)", "CravarFPS"),
    LIGHT_UI("Interface Leve & Otimizador Geral", "InterfaceLeve")
}

data class AndroidCommand(
    val id: String,
    val moduleId: ModuleId,
    val command: String,
    val description: String,
    val namespace: CommandNamespace,
    val minSdk: Int = 26,
    val maxSdk: Int = 36
)

data class OptimizationModule(
    val id: ModuleId,
    val title: String,
    val subtitle: String,
    val badgeTag: String,
    val category: ModuleCategory,
    val commands: List<AndroidCommand>,
    val isEnabled: Boolean = false,
    val isCompatible: Boolean = true,
    val incompatibilityReason: String? = null
)

enum class FreeFireVersion(val displayName: String, val shortName: String, val packageName: String) {
    NORMAL("Free Fire Normal", "FF NORMAL", "com.dts.freefireth"),
    MAX("Free Fire MAX", "FF MAX", "com.dts.freefiremax")
}

data class NamespaceSupport(
    val settingsSystem: Boolean = true,
    val settingsSecure: Boolean = true,
    val settingsGlobal: Boolean = true,
    val deviceConfig: Boolean = true,
    val cmdPower: Boolean = true,
    val cmdDisplay: Boolean = true,
    val cmdThermal: Boolean = true,
    val cmdGame: Boolean = false,
    val highRefreshSupported: Boolean = false
)

data class DeviceProfile(
    val manufacturer: String,
    val brandName: String,
    val vendorBrand: VendorBrand,
    val model: String,
    val sdkInt: Int,
    val androidRelease: String,
    val supportedRefreshRates: List<Int>,
    val maxSupportedHz: Int,
    val selectedTargetHz: Int,
    val currentDpi: Int,
    val defaultDpi: Int,
    val widthPx: Int,
    val heightPx: Int,
    val namespaceSupport: NamespaceSupport,
    val freeFireNormalInstalled: Boolean,
    val freeFireMaxInstalled: Boolean
)

data class SensitivityProfile(
    val geral: Int = 165,
    val redDot: Int = 152,
    val scope2x: Int = 144,
    val scope4x: Int = 138,
    val awm: Int = 122,
    val olhadinha: Int = 158
)

data class GeneratedSensiRecommendation(
    val profile: SensitivityProfile,
    val idealDpi: Int,
    val fireButtonSizePercent: Int,
    val dragTip: String,
    val deviceSummary: String
)

enum class CrosshairShape(val label: String) {
    CROSS("Cruz Tática"),
    DOT("Ponto Preciso"),
    CIRCLE_CROSS("Círculo + Cruz"),
    DIAMOND("Diamante"),
    TACTICAL_X("X Gamer")
}

enum class CrosshairColorOption(val label: String, val hexColor: Long, val composeColor: Color) {
    CYAN("Ciano Neon", 0xFF00F0FF, FangxCyan),
    RED("Vermelho", 0xFFFF2A54, FangxRed),
    GREEN("Verde Tático", 0xFF00E676, FangxGreen),
    YELLOW("Amarelo", 0xFFFFD600, Color(0xFFFFD600)),
    WHITE("Branco Puro", 0xFFFFFFFF, Color(0xFFFFFFFF))
}

data class CrosshairConfig(
    val enabled: Boolean = false,
    val shape: CrosshairShape = CrosshairShape.CIRCLE_CROSS,
    val colorOption: CrosshairColorOption = CrosshairColorOption.CYAN,
    val sizeDp: Float = 32f,
    val opacity: Float = 0.9f,
    val offsetX: Int = 0,
    val offsetY: Int = 0
)

enum class LogStatus {
    INFO,
    SUCCESS,
    WARN,
    ERROR
}

data class TerminalLogEntry(
    val index: Int,
    val total: Int,
    val command: String,
    val status: LogStatus,
    val detail: String
)

enum class ShizukuStatus(val label: String) {
    CONNECTED("SHIZUKU ATIVO"),
    PERMISSION_REQUIRED("PERMISSÃO PENDENTE"),
    NOT_RUNNING("SHIZUKU INATIVO")
}

enum class MainTab(val label: String) {
    MIRA("Mira"),
    FPS("FPS"),
    SENSI("Sensi"),
    SOBRE("Sobre")
}
