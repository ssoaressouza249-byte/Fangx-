package com.raylan.fangx.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.LayersClear
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.raylan.fangx.model.DeviceProfile
import com.raylan.fangx.model.ModuleCategory
import com.raylan.fangx.model.ModuleId
import com.raylan.fangx.model.OptimizationModule
import com.raylan.fangx.ui.components.ModuleCard
import com.raylan.fangx.ui.theme.FangxBorder
import com.raylan.fangx.ui.theme.FangxCyan
import com.raylan.fangx.ui.theme.FangxGreen
import com.raylan.fangx.ui.theme.FangxRed
import com.raylan.fangx.ui.theme.FangxSurface
import com.raylan.fangx.ui.theme.FangxSurfaceElevated
import com.raylan.fangx.ui.theme.FangxTextPrimary
import com.raylan.fangx.ui.theme.FangxTextSecondary

@Composable
fun ModulesTabScreen(
    category: ModuleCategory,
    modules: List<OptimizationModule>,
    deviceProfile: DeviceProfile,
    onToggleModule: (ModuleId) -> Unit,
    onSelectAll: (Boolean) -> Unit,
    onSelectTargetHz: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val isMira = category == ModuleCategory.MIRA
    val accent = if (isMira) FangxCyan else FangxRed
    val filteredModules = modules.filter { it.category == category }
    val totalCategoryCommands = filteredModules.sumOf { it.commands.size }
    val activeCount = filteredModules.count { it.isEnabled && it.isCompatible }

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .fillMaxSize()
            .testTag(if (isMira) "screen_mira" else "screen_fps")
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = FangxSurface,
                border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 640.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isMira) "MIRA & PRECISION" else "DESEMPENHO, BONECO LENTO & FPS",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                                color = accent
                            )
                            Text(
                                text = "$totalCategoryCommands comandos reais • $activeCount/${filteredModules.size} módulos marcados",
                                style = MaterialTheme.typography.labelSmall,
                                color = FangxTextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = FangxSurfaceElevated,
                        border = BorderStroke(1.dp, FangxBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Shield,
                                contentDescription = null,
                                tint = FangxGreen,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Nenhuma função é aplicada antes de clicar em INJETAR.",
                                style = MaterialTheme.typography.labelSmall,
                                color = FangxTextPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        QuickActionChip(
                            label = "Ativar Compatíveis",
                            icon = Icons.Rounded.DoneAll,
                            accent = accent,
                            onClick = { onSelectAll(true) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("select_all_${category.name.lowercase()}")
                        )
                        QuickActionChip(
                            label = "Desmarcar Todos",
                            icon = Icons.Rounded.LayersClear,
                            accent = FangxTextSecondary,
                            onClick = { onSelectAll(false) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("clear_all_${category.name.lowercase()}")
                        )
                    }
                }
            }
        }

        if (!isMira) {
            item {
                val highHzOptions = deviceProfile.supportedRefreshRates.filter { it >= 90 }
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = FangxSurface,
                    border = BorderStroke(1.dp, FangxBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 640.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.Refresh,
                                contentDescription = null,
                                tint = FangxRed,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "TAXAS DE TELA SUPORTADAS NESTE APARELHO",
                                style = MaterialTheme.typography.labelMedium,
                                color = FangxTextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        if (highHzOptions.isEmpty()) {
                            Text(
                                text = "Display limitado a ${deviceProfile.maxSupportedHz}Hz nativos. Alta taxa (90/120/144Hz) bloqueada pelo hardware.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = FangxTextSecondary
                            )
                        } else {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                highHzOptions.forEach { hz ->
                                    val selected = deviceProfile.selectedTargetHz == hz
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (selected) FangxRed.copy(alpha = 0.2f) else FangxSurfaceElevated,
                                        border = BorderStroke(1.dp, if (selected) FangxRed else FangxBorder),
                                        modifier = Modifier
                                            .weight(1f)
                                            .minimumInteractiveComponentSize()
                                            .clickable { onSelectTargetHz(hz) }
                                            .testTag("hz_chip_$hz")
                                    ) {
                                        Row(
                                            horizontalArrangement = Arrangement.Center,
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(vertical = 10.dp)
                                        ) {
                                            Text(
                                                text = "${hz}Hz",
                                                style = MaterialTheme.typography.titleSmall,
                                                color = if (selected) FangxRed else FangxTextPrimary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        items(filteredModules, key = { it.id.name }) { module ->
            ModuleCard(
                module = module,
                onToggle = { onToggleModule(module.id) },
                modifier = Modifier.widthIn(max = 640.dp)
            )
        }
    }
}

@Composable
private fun QuickActionChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: androidx.compose.ui.graphics.Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = FangxSurfaceElevated,
        border = BorderStroke(1.dp, FangxBorder),
        modifier = modifier
            .minimumInteractiveComponentSize()
            .clickable { onClick() }
    ) {
        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = accent,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = FangxTextPrimary,
                maxLines = 1
            )
        }
    }
}
