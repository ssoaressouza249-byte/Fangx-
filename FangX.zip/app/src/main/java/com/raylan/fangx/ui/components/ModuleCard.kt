package com.raylan.fangx.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.GpsFixed
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.raylan.fangx.model.ModuleCategory
import com.raylan.fangx.model.OptimizationModule
import com.raylan.fangx.ui.theme.FangxBg
import com.raylan.fangx.ui.theme.FangxBorder
import com.raylan.fangx.ui.theme.FangxCyan
import com.raylan.fangx.ui.theme.FangxRed
import com.raylan.fangx.ui.theme.FangxSurface
import com.raylan.fangx.ui.theme.FangxSurfaceElevated
import com.raylan.fangx.ui.theme.FangxTextMuted
import com.raylan.fangx.ui.theme.FangxTextPrimary
import com.raylan.fangx.ui.theme.FangxTextSecondary

@Composable
fun ModuleCard(
    module: OptimizationModule,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember(module.id) { mutableStateOf(false) }

    val isMira = module.category == ModuleCategory.MIRA
    val accentColor = if (isMira) FangxCyan else FangxRed
    val borderColor = when {
        !module.isCompatible -> FangxRed.copy(alpha = 0.45f)
        module.isEnabled -> accentColor.copy(alpha = 0.85f)
        else -> FangxBorder
    }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = FangxSurface,
        border = BorderStroke(if (module.isEnabled) 1.5.dp else 1.dp, borderColor),
        modifier = modifier
            .fillMaxWidth()
            .testTag("module_card_${module.id.name.lowercase()}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (module.isCompatible) accentColor.copy(alpha = 0.14f) else FangxRed.copy(alpha = 0.14f),
                    modifier = Modifier.size(42.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = when {
                                !module.isCompatible -> Icons.Rounded.Block
                                isMira -> Icons.Rounded.GpsFixed
                                else -> Icons.Rounded.Bolt
                            },
                            contentDescription = module.title,
                            tint = if (module.isCompatible) accentColor else FangxRed,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = module.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (module.isCompatible) FangxTextPrimary else FangxTextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = FangxSurfaceElevated,
                            border = BorderStroke(1.dp, FangxBorder)
                        ) {
                            Text(
                                text = module.badgeTag,
                                style = MaterialTheme.typography.labelSmall,
                                color = accentColor,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(3.dp))

                    Text(
                        text = module.subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = FangxTextSecondary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Switch(
                    checked = module.isEnabled,
                    onCheckedChange = { if (module.isCompatible) onToggle() },
                    enabled = module.isCompatible,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = FangxBg,
                        checkedTrackColor = accentColor,
                        uncheckedThumbColor = FangxTextSecondary,
                        uncheckedTrackColor = FangxSurfaceElevated,
                        uncheckedBorderColor = FangxBorder,
                        disabledUncheckedTrackColor = FangxSurfaceElevated.copy(alpha = 0.5f),
                        disabledUncheckedThumbColor = FangxTextMuted
                    ),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("module_switch_${module.id.name.lowercase()}")
                )
            }

            if (!module.isCompatible) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = FangxRed.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, FangxRed.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("incompatible_badge_${module.id.name.lowercase()}")
                ) {
                    Text(
                        text = module.incompatibilityReason ?: "INCOMPATÍVEL COM ESTE APARELHO",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.ExtraBold),
                        color = FangxRed,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .clickable { expanded = !expanded }
                    .padding(vertical = 4.dp)
                    .testTag("expand_commands_${module.id.name.lowercase()}")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.Terminal,
                        contentDescription = null,
                        tint = FangxTextMuted,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (expanded) "Ocultar ${module.commands.size} comandos reais"
                        else "Inspecionar ${module.commands.size} comandos reais",
                        style = MaterialTheme.typography.labelSmall,
                        color = FangxTextSecondary
                    )
                }
                Icon(
                    imageVector = if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                    contentDescription = if (expanded) "Recolher comandos" else "Expandir comandos",
                    tint = FangxTextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }

            AnimatedVisibility(visible = expanded) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = FangxBg,
                    border = BorderStroke(1.dp, FangxBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp)
                ) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(10.dp)
                    ) {
                        module.commands.forEachIndexed { index, cmd ->
                            Column {
                                Text(
                                    text = "${(index + 1).toString().padStart(2, '0')}. ${cmd.command}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = accentColor
                                )
                                Text(
                                    text = "    // ${cmd.description}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = FangxTextMuted
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
