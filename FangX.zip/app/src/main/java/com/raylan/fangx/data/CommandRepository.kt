package com.raylan.fangx.data

import com.raylan.fangx.model.AndroidCommand
import com.raylan.fangx.model.DeviceProfile
import com.raylan.fangx.model.ModuleCategory
import com.raylan.fangx.model.ModuleId
import com.raylan.fangx.model.OptimizationModule

object CommandRepository {

    fun buildModules(
        profile: DeviceProfile,
        currentSelection: Map<ModuleId, Boolean> = emptyMap()
    ): List<OptimizationModule> {
        val miraMap = MiraCommandBank.buildCommands(profile)
        val perfMap = PerformanceCommandBank.buildCommands(profile)
        val sdk = profile.sdkInt
        val ns = profile.namespaceSupport

        val rawDefinitions = listOf(
            ModuleDefinition(
                id = ModuleId.AIMBOT,
                title = "Aimbot",
                subtitle = "Velocidade máxima de ponteiro, resposta de toque e redução de touch slop",
                badgeTag = "20 CMD",
                category = ModuleCategory.MIRA,
                commands = miraMap[ModuleId.AIMBOT].orEmpty(),
                compatible = ns.settingsSystem && ns.settingsSecure,
                incompatibilityReason = if (!ns.settingsSystem) "INCOMPATÍVEL COM ESTE APARELHO" else null
            ),
            ModuleDefinition(
                id = ModuleId.AIMLOCK,
                title = "Aimlock",
                subtitle = "Estabilização linear de eixo X/Y e calibração de arrasto contínuo",
                badgeTag = "18 CMD",
                category = ModuleCategory.MIRA,
                commands = miraMap[ModuleId.AIMLOCK].orEmpty(),
                compatible = ns.settingsSystem && ns.settingsSecure,
                incompatibilityReason = if (!ns.settingsSecure) "INCOMPATÍVEL COM ESTE APARELHO" else null
            ),
            ModuleDefinition(
                id = ModuleId.NO_RECOIL,
                title = "No Recoil",
                subtitle = "Controle vertical, micro-deslizamento e transition_animation_scale 0.0",
                badgeTag = "16 CMD",
                category = ModuleCategory.MIRA,
                commands = miraMap[ModuleId.NO_RECOIL].orEmpty(),
                compatible = ns.settingsGlobal,
                incompatibilityReason = if (!ns.settingsGlobal) "INCOMPATÍVEL COM ESTE APARELHO" else null
            ),
            ModuleDefinition(
                id = ModuleId.NO_RECOIL_2,
                title = "No Recoil 2",
                subtitle = "Leitura multi-touch simultânea e redução de latência do buffer de toque",
                badgeTag = "16 CMD",
                category = ModuleCategory.MIRA,
                commands = miraMap[ModuleId.NO_RECOIL_2].orEmpty(),
                compatible = ns.settingsSystem && ns.settingsGlobal,
                incompatibilityReason = if (!ns.settingsGlobal) "INCOMPATÍVEL COM ESTE APARELHO" else null
            ),
            ModuleDefinition(
                id = ModuleId.AIMBOT_2X,
                title = "Aimbot 2x",
                subtitle = "Precisão fina e subpixel para miras telescópicas 2x, 4x e AWM",
                badgeTag = "15 CMD",
                category = ModuleCategory.MIRA,
                commands = miraMap[ModuleId.AIMBOT_2X].orEmpty(),
                compatible = ns.settingsSystem && ns.settingsSecure,
                incompatibilityReason = if (!ns.settingsSystem) "INCOMPATÍVEL COM ESTE APARELHO" else null
            ),
            ModuleDefinition(
                id = ModuleId.HS_75,
                title = "HS 75%",
                subtitle = "Curva rápida de puxada vertical, animator 0.0 e prioridade máxima de input",
                badgeTag = "15 CMD",
                category = ModuleCategory.MIRA,
                commands = miraMap[ModuleId.HS_75].orEmpty(),
                compatible = ns.settingsGlobal && ns.settingsSystem,
                incompatibilityReason = if (!ns.settingsGlobal) "INCOMPATÍVEL COM ESTE APARELHO" else null
            ),
            ModuleDefinition(
                id = ModuleId.BONECO_LENTO,
                title = "Modo Boneco Lento",
                subtitle = "Fluidez extrema de animação (0.0) e frame pacing sincronizado no SurfaceFlinger",
                badgeTag = "20 CMD",
                category = ModuleCategory.PERFORMANCE,
                commands = perfMap[ModuleId.BONECO_LENTO].orEmpty(),
                compatible = ns.settingsGlobal,
                incompatibilityReason = if (!ns.settingsGlobal) "INCOMPATÍVEL COM ESTE APARELHO" else null
            ),
            ModuleDefinition(
                id = ModuleId.FORCE_HZ,
                title = "Forçar Hz (90Hz / 120Hz / 144Hz)",
                subtitle = if (ns.highRefreshSupported) {
                    "Trava taxa de atualização em ${profile.selectedTargetHz}Hz (máx. suportado: ${profile.maxSupportedHz}Hz)"
                } else {
                    "Tela limitada a ${profile.maxSupportedHz}Hz nativos — alta taxa indisponível"
                },
                badgeTag = "15 CMD",
                category = ModuleCategory.PERFORMANCE,
                commands = perfMap[ModuleId.FORCE_HZ].orEmpty(),
                compatible = ns.highRefreshSupported,
                incompatibilityReason = if (!ns.highRefreshSupported) "INCOMPATÍVEL COM ESTE APARELHO" else null
            ),
            ModuleDefinition(
                id = ModuleId.TURBO_BOOST,
                title = "Turbo Boost CPU & GPU",
                subtitle = "Renderização HWUI/SurfaceFlinger, performance fixa e prioridade de processamento",
                badgeTag = "25 CMD",
                category = ModuleCategory.PERFORMANCE,
                commands = perfMap[ModuleId.TURBO_BOOST].orEmpty(),
                compatible = ns.settingsGlobal && (sdk < 30 || ns.cmdPower),
                incompatibilityReason = if (!ns.settingsGlobal) "INCOMPATÍVEL COM ESTE APARELHO" else null
            ),
            ModuleDefinition(
                id = ModuleId.LOCK_FPS,
                title = "Cravar FPS (90 - 100 FPS)",
                subtitle = "GameManager, estabilidade térmica e buffers gráficos otimizados",
                badgeTag = "20 CMD",
                category = ModuleCategory.PERFORMANCE,
                commands = perfMap[ModuleId.LOCK_FPS].orEmpty(),
                compatible = sdk >= 31 && ns.cmdGame && ns.deviceConfig,
                incompatibilityReason = if (sdk < 31 || !ns.cmdGame) "INCOMPATÍVEL COM ESTE APARELHO" else null
            ),
            ModuleDefinition(
                id = ModuleId.LIGHT_UI,
                title = "Interface Leve & Otimizador Geral",
                subtitle = "Limpeza de caches (pm trim-caches), encerramento de background e SystemUI leve",
                badgeTag = "20 CMD",
                category = ModuleCategory.PERFORMANCE,
                commands = perfMap[ModuleId.LIGHT_UI].orEmpty(),
                compatible = true,
                incompatibilityReason = null
            )
        )

        return rawDefinitions.map { def ->
            val enabled = if (def.compatible) currentSelection[def.id] ?: false else false
            OptimizationModule(
                id = def.id,
                title = def.title,
                subtitle = def.subtitle,
                badgeTag = def.badgeTag,
                category = def.category,
                commands = def.commands,
                isEnabled = enabled,
                isCompatible = def.compatible,
                incompatibilityReason = def.incompatibilityReason
            )
        }
    }

    fun filterApplicableCommands(
        modules: List<OptimizationModule>,
        sdkInt: Int
    ): List<AndroidCommand> {
        return modules
            .filter { it.isEnabled && it.isCompatible }
            .flatMap { it.commands }
            .filter { sdkInt in it.minSdk..it.maxSdk || it.minSdk <= sdkInt }
    }

    private data class ModuleDefinition(
        val id: ModuleId,
        val title: String,
        val subtitle: String,
        val badgeTag: String,
        val category: ModuleCategory,
        val commands: List<AndroidCommand>,
        val compatible: Boolean,
        val incompatibilityReason: String?
    )
}
