package com.raylan.fangx

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.raylan.fangx.model.MainTab
import com.raylan.fangx.model.ModuleCategory
import com.raylan.fangx.security.SecurityState
import com.raylan.fangx.ui.FangxUiState
import com.raylan.fangx.ui.FangxViewModel
import com.raylan.fangx.ui.components.FangxBottomInjectionBar
import com.raylan.fangx.ui.components.FangxTabBar
import com.raylan.fangx.ui.components.FangxTopHeader
import com.raylan.fangx.ui.components.InjectionTerminalDialog
import com.raylan.fangx.ui.components.SecurityLockoutScreen
import com.raylan.fangx.ui.screens.ModulesTabScreen
import com.raylan.fangx.ui.screens.SensiScreen
import com.raylan.fangx.ui.screens.SobreScreen
import com.raylan.fangx.ui.theme.FangxBg
import com.raylan.fangx.ui.theme.FangxTheme

class MainActivity : ComponentActivity() {

    private val viewModel: FangxViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )
        setContent {
            FangxTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                val lifecycleOwner = LocalLifecycleOwner.current

                DisposableEffect(lifecycleOwner) {
                    val observer = LifecycleEventObserver { _, event ->
                        if (event == Lifecycle.Event.ON_RESUME) {
                            viewModel.onAppResume()
                        }
                    }
                    lifecycleOwner.lifecycle.addObserver(observer)
                    onDispose {
                        lifecycleOwner.lifecycle.removeObserver(observer)
                    }
                }

                when (val sec = uiState.securityState) {
                    is SecurityState.Tampered -> {
                        SecurityLockoutScreen(technicalDetail = sec.technicalDetail)
                    }
                    is SecurityState.Verified -> {
                        FangxMainApp(uiState = uiState, viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@Composable
private fun FangxMainApp(
    uiState: FangxUiState,
    viewModel: FangxViewModel
) {
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.statusBannerMessage) {
        val message = uiState.statusBannerMessage
        if (message != null) {
            snackbarHostState.showSnackbar(message)
            viewModel.dismissBannerMessage()
        }
    }

    if (uiState.selectedTab != MainTab.MIRA) {
        BackHandler {
            viewModel.selectTab(MainTab.MIRA)
        }
    }

    Scaffold(
        containerColor = FangxBg,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            Column {
                FangxTopHeader(
                    deviceProfile = uiState.deviceProfile,
                    shizukuStatus = uiState.shizukuStatus,
                    onShizukuClick = viewModel::requestShizukuPermission
                )
                FangxTabBar(
                    selectedTab = uiState.selectedTab,
                    onSelectTab = viewModel::selectTab
                )
            }
        },
        bottomBar = {
            FangxBottomInjectionBar(
                selectedFreeFire = uiState.selectedFreeFire,
                normalInstalled = uiState.deviceProfile.freeFireNormalInstalled,
                maxInstalled = uiState.deviceProfile.freeFireMaxInstalled,
                activeCommandCount = uiState.activeCommandCount,
                isInjecting = uiState.isInjecting,
                onSelectFreeFire = viewModel::selectFreeFireVersion,
                onInjectAndLaunch = viewModel::startCadencedInjectionAndLaunch
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (uiState.selectedTab) {
                MainTab.MIRA -> ModulesTabScreen(
                    category = ModuleCategory.MIRA,
                    modules = uiState.modules,
                    deviceProfile = uiState.deviceProfile,
                    onToggleModule = viewModel::toggleModule,
                    onSelectAll = { enable -> viewModel.selectAllCategory(enable, isMira = true) },
                    onSelectTargetHz = viewModel::selectTargetHz
                )
                MainTab.FPS -> ModulesTabScreen(
                    category = ModuleCategory.PERFORMANCE,
                    modules = uiState.modules,
                    deviceProfile = uiState.deviceProfile,
                    onToggleModule = viewModel::toggleModule,
                    onSelectAll = { enable -> viewModel.selectAllCategory(enable, isMira = false) },
                    onSelectTargetHz = viewModel::selectTargetHz
                )
                MainTab.SENSI -> SensiScreen(
                    crosshairConfig = uiState.crosshairConfig,
                    hasOverlayPermission = uiState.hasOverlayPermission,
                    sensitivity = uiState.sensitivity,
                    generatedRecommendation = uiState.generatedRecommendation,
                    deviceProfile = uiState.deviceProfile,
                    dpiInput = uiState.dpiInput,
                    dpiStatusMessage = uiState.dpiStatusMessage,
                    onToggleOverlay = viewModel::toggleFloatingCrosshair,
                    onOpenOverlaySettings = viewModel::openOverlayPermissionSettings,
                    onUpdateShape = viewModel::updateCrosshairShape,
                    onUpdateColor = viewModel::updateCrosshairColor,
                    onUpdateSize = viewModel::updateCrosshairSize,
                    onUpdateOpacity = viewModel::updateCrosshairOpacity,
                    onUpdateSensitivity = viewModel::updateSensitivity,
                    onGeneratePerfectSensi = viewModel::generatePerfectSensitivity,
                    onUpdateDpiInput = viewModel::updateDpiInput,
                    onApplyDpi = viewModel::applyDpiViaShizuku,
                    onRestoreDefaultDpi = viewModel::restoreDefaultDpiViaShizuku
                )
                MainTab.SOBRE -> SobreScreen(
                    deviceProfile = uiState.deviceProfile,
                    totalCommandsCount = uiState.totalCommandBankCount,
                    onRescanDevice = viewModel::rescanCompatibility
                )
            }
        }
    }

    if (uiState.showTerminalModal) {
        InjectionTerminalDialog(
            isInjecting = uiState.isInjecting,
            isComplete = uiState.injectionComplete,
            progress = uiState.injectionProgress,
            total = uiState.injectionTotal,
            logs = uiState.terminalLogs,
            onClose = viewModel::closeTerminalModal
        )
    }
}
