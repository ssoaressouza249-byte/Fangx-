package com.raylan.fangx.security

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.raylan.fangx.R
import com.raylan.fangx.engine.CoreModuleSignatures
import com.raylan.fangx.engine.ModuleSignature
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

sealed class SecurityState {
    data object Verified : SecurityState()
    data class Tampered(val technicalDetail: String) : SecurityState()
}

object SecurityGuard {

    const val EXPECTED_APP_NAME = "Fangx"
    const val EXPECTED_PACKAGE_NAME = "com.raylan.fangx"

    const val LOCKOUT_MESSAGE =
        "DESINSTALAR APP - POIS ESSE NÃO É A VERSÃO OFICIAL DO CRIADOR. ESTA VERSÃO FOI MODIFICADA. POR FAVOR ABRA O NOSSO DISCORD OFICIAL E ADQUIRA A VERSÃO VIP OFICIAL."

    private val expectedMethods = mapOf(
        "Aimbot" to "Aimbot",
        "Aimlock" to "Aimlock",
        "NoRecoil" to "No Recoil",
        "NoRecoil2" to "No Recoil 2",
        "Aimbot2x" to "Aimbot 2x",
        "Hs75" to "HS 75%",
        "BonecoLento" to "Boneco Lento"
    )

    /**
     * Realiza verificação completa sem bloquear certificados de debug (como GitHub Actions).
     */
    fun verifyIntegrity(context: Context): SecurityState {
        val packageCheck = runCatching { context.packageName }.getOrElse { "" }
        if (packageCheck != EXPECTED_PACKAGE_NAME) {
            return SecurityState.Tampered(
                "PACKAGE_TAMPERED: esperado '$EXPECTED_PACKAGE_NAME', detectado '$packageCheck'"
            )
        }

        val labelCheck = runCatching {
            context.applicationInfo.loadLabel(context.packageManager).toString()
        }.getOrElse { "" }
        if (labelCheck != EXPECTED_APP_NAME) {
            return SecurityState.Tampered(
                "APP_LABEL_TAMPERED: esperado '$EXPECTED_APP_NAME', detectado '$labelCheck'"
            )
        }

        val stringResCheck = runCatching {
            context.getString(R.string.app_name)
        }.getOrElse { "" }
        if (stringResCheck != EXPECTED_APP_NAME) {
            return SecurityState.Tampered(
                "STRING_RES_TAMPERED: R.string.app_name='$stringResCheck'"
            )
        }

        val signatureIssue = verifyCoreSignatures()
        if (signatureIssue != null) {
            return SecurityState.Tampered(signatureIssue)
        }

        return SecurityState.Verified
    }

    private fun verifyCoreSignatures(): String? {
        return runCatching {
            val clazz = CoreModuleSignatures::class.java
            if (clazz.name != "com.raylan.fangx.engine.CoreModuleSignatures") {
                return@runCatching "CLASS_RENAMED: ${clazz.name}"
            }

            val methodsByName = clazz.declaredMethods.associateBy { it.name }
            for ((methodName, expectedToken) in expectedMethods) {
                val method = methodsByName[methodName]
                    ?: return@runCatching "METHOD_MISSING: '$methodName' ($expectedToken) não encontrado"

                if (method.returnType != String::class.java) {
                    return@runCatching "SIGNATURE_MODIFIED: retorno alterado em '$methodName'"
                }

                val annotation = method.getAnnotation(ModuleSignature::class.java)
                    ?: return@runCatching "ANNOTATION_STRIPPED: @ModuleSignature ausente em '$methodName'"

                if (annotation.token != expectedToken) {
                    return@runCatching "TOKEN_MODIFIED: esperado '$expectedToken', obtido '${annotation.token}'"
                }
            }

            val actualDigest = CoreModuleSignatures.computeIntegrityDigest()
            val expectedDigest = CoreModuleSignatures.expectedDigestHash()
            if (actualDigest != expectedDigest) {
                return@runCatching "DIGEST_MISMATCH: assinatura SHA-256 divergente"
            }

            null
        }.getOrElse { error ->
            "REFLECTION_INTEGRITY_ERROR: ${error.javaClass.simpleName} - ${error.message}"
        }
    }

    fun observeIntegrity(context: Context, intervalMs: Long = 1500L): Flow<SecurityState> = flow {
        while (true) {
            val state = verifyIntegrity(context)
            emit(state)
            if (state is SecurityState.Tampered) break
            delay(intervalMs)
        }
    }

    fun buildUninstallIntent(context: Context): Intent {
        return Intent(Intent.ACTION_DELETE, Uri.parse("package:${context.packageName}")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }
}
