package com.raylan.fangx.engine

import android.content.Context
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.os.Build
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Display
import com.raylan.fangx.model.DeviceProfile
import com.raylan.fangx.model.FreeFireVersion
import com.raylan.fangx.model.GeneratedSensiRecommendation
import com.raylan.fangx.model.NamespaceSupport
import com.raylan.fangx.model.SensitivityProfile
import com.raylan.fangx.model.VendorBrand
import kotlin.math.roundToInt

object DeviceCompatibilityScanner {

    fun scanDevice(context: Context, previousTargetHz: Int? = null): DeviceProfile {
        val manufacturer = runCatching { Build.MANUFACTURER.orEmpty() }.getOrDefault("Android")
        val brand = runCatching { Build.BRAND.orEmpty() }.getOrDefault(manufacturer)
        val model = runCatching { Build.MODEL.orEmpty() }.getOrDefault("Dispositivo")
        val sdkInt = Build.VERSION.SDK_INT
        val release = runCatching { Build.VERSION.RELEASE.orEmpty() }.getOrDefault("$sdkInt")
        val vendorBrand = resolveVendor(manufacturer, brand)

        val refreshRates = detectSupportedRefreshRates(context)
        val maxHz = refreshRates.maxOrNull() ?: 60
        val highHzRates = refreshRates.filter { it >= 90 }
        val targetHz = when {
            previousTargetHz != null && refreshRates.contains(previousTargetHz) -> previousTargetHz
            highHzRates.isNotEmpty() -> highHzRates.max()
            else -> maxHz
        }

        val metrics = runCatching { context.resources.displayMetrics }.getOrNull()
        val currentDpi = metrics?.densityDpi ?: DisplayMetrics.DENSITY_XHIGH
        val defaultDpi = runCatching { DisplayMetrics.DENSITY_DEVICE_STABLE }.getOrDefault(currentDpi)
        val widthPx = metrics?.widthPixels ?: 1080
        val heightPx = metrics?.heightPixels ?: 2400

        val namespaceSupport = probeNamespaces(context, sdkInt, maxHz)

        val ffNormalInstalled = isPackageInstalled(context, FreeFireVersion.NORMAL.packageName)
        val ffMaxInstalled = isPackageInstalled(context, FreeFireVersion.MAX.packageName)

        return DeviceProfile(
            manufacturer = manufacturer.ifBlank { "Android" },
            brandName = brand.ifBlank { manufacturer },
            vendorBrand = vendorBrand,
            model = model.ifBlank { "Smartphone" },
            sdkInt = sdkInt,
            androidRelease = release,
            supportedRefreshRates = refreshRates,
            maxSupportedHz = maxHz,
            selectedTargetHz = targetHz,
            currentDpi = currentDpi,
            defaultDpi = defaultDpi,
            widthPx = widthPx,
            heightPx = heightPx,
            namespaceSupport = namespaceSupport,
            freeFireNormalInstalled = ffNormalInstalled,
            freeFireMaxInstalled = ffMaxInstalled
        )
    }

    private fun resolveVendor(manufacturer: String, brand: String): VendorBrand {
        val combined = "$manufacturer $brand".lowercase()
        return when {
            "samsung" in combined -> VendorBrand.SAMSUNG
            "xiaomi" in combined || "poco" in combined || "redmi" in combined -> VendorBrand.XIAOMI
            "motorola" in combined || "moto" in combined -> VendorBrand.MOTOROLA
            "realme" in combined || "oppo" in combined || "oneplus" in combined -> VendorBrand.REALME_OPPO
            "asus" in combined || "rog" in combined -> VendorBrand.ASUS
            else -> VendorBrand.GENERIC
        }
    }

    private fun detectSupportedRefreshRates(context: Context): List<Int> {
        return runCatching {
            val dm = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
            val display: Display? = dm?.getDisplay(Display.DEFAULT_DISPLAY)
            val modes = display?.supportedModes.orEmpty()
            val rates = modes
                .map { it.refreshRate.roundToInt() }
                .filter { it >= 59 }
                .map { rate ->
                    when {
                        rate in 59..62 -> 60
                        rate in 88..92 -> 90
                        rate in 118..122 -> 120
                        rate in 140..146 -> 144
                        else -> rate
                    }
                }
                .distinct()
                .sorted()
            if (rates.isEmpty()) listOf(60) else rates
        }.getOrDefault(listOf(60))
    }

    private fun probeNamespaces(
        context: Context,
        sdkInt: Int,
        maxSupportedHz: Int
    ): NamespaceSupport {
        val resolver = context.contentResolver
        val systemOk = runCatching {
            Settings.System.getInt(resolver, Settings.System.SCREEN_BRIGHTNESS, 128)
            true
        }.getOrDefault(false)

        val secureOk = runCatching {
            Settings.Secure.getString(resolver, Settings.Secure.ANDROID_ID)
            true
        }.getOrDefault(true)

        val globalOk = runCatching {
            Settings.Global.getFloat(resolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f)
            true
        }.getOrDefault(true)

        val deviceConfigSupported = sdkInt >= Build.VERSION_CODES.Q
        val cmdPowerSupported = sdkInt >= Build.VERSION_CODES.Q
        val cmdDisplaySupported = sdkInt >= Build.VERSION_CODES.S
        val cmdThermalSupported = sdkInt >= Build.VERSION_CODES.Q
        val cmdGameSupported = sdkInt >= Build.VERSION_CODES.S

        return NamespaceSupport(
            settingsSystem = systemOk,
            settingsSecure = secureOk,
            settingsGlobal = globalOk,
            deviceConfig = deviceConfigSupported,
            cmdPower = cmdPowerSupported,
            cmdDisplay = cmdDisplaySupported,
            cmdThermal = cmdThermalSupported,
            cmdGame = cmdGameSupported,
            highRefreshSupported = maxSupportedHz >= 90
        )
    }

    fun isPackageInstalled(context: Context, packageName: String): Boolean {
        return runCatching {
            val pm = context.packageManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(packageName, 0)
            }
            true
        }.getOrDefault(false)
    }

    fun generatePerfectSensitivity(profile: DeviceProfile): GeneratedSensiRecommendation {
        val baseBoost = when (profile.vendorBrand) {
            VendorBrand.XIAOMI -> 182
            VendorBrand.SAMSUNG -> 174
            VendorBrand.ASUS -> 186
            VendorBrand.REALME_OPPO -> 178
            VendorBrand.MOTOROLA -> 170
            VendorBrand.GENERIC -> 172
        }

        val hzBonus = when {
            profile.maxSupportedHz >= 144 -> 10
            profile.maxSupportedHz >= 120 -> 6
            profile.maxSupportedHz >= 90 -> 3
            else -> 0
        }

        val dpiCompensation = when {
            profile.currentDpi <= 360 -> 8
            profile.currentDpi >= 480 -> -6
            else -> 0
        }

        fun clampSensi(value: Int): Int = value.coerceIn(100, 200)

        val geral = clampSensi(baseBoost + hzBonus + dpiCompensation)
        val redDot = clampSensi(geral - 9)
        val scope2x = clampSensi(geral - 16)
        val scope4x = clampSensi(geral - 24)
        val awm = clampSensi(112 + hzBonus + (if (profile.vendorBrand == VendorBrand.XIAOMI) 8 else 4))
        val olhadinha = clampSensi(geral - 4)

        val idealDpi = when {
            profile.maxSupportedHz >= 120 && profile.currentDpi >= 400 -> 596
            profile.vendorBrand == VendorBrand.SAMSUNG -> 580
            profile.vendorBrand == VendorBrand.XIAOMI -> 600
            profile.vendorBrand == VendorBrand.MOTOROLA -> 540
            else -> 560
        }

        val fireButtonPercent = when {
            profile.maxSupportedHz >= 120 -> 45
            profile.currentDpi <= 380 -> 50
            else -> 47
        }

        val dragTip = when {
            profile.maxSupportedHz >= 120 ->
                "Tela ${profile.maxSupportedHz}Hz detectada: faça puxada curta e explosiva em linha reta até a linha do capacete."
            profile.vendorBrand == VendorBrand.SAMSUNG ->
                "Painel OneUI: inicie o toque levemente abaixo do centro do botão e suba em curva 'J' rápida."
            profile.vendorBrand == VendorBrand.XIAOMI ->
                "Digitalizador MIUI/HyperOS: arraste rápido de baixo para cima sem segurar o botão na base."
            else ->
                "Sincronize o tempo da mira branca no peito do oponente e puxe verticalmente com ritmo constante."
        }

        return GeneratedSensiRecommendation(
            profile = SensitivityProfile(
                geral = geral,
                redDot = redDot,
                scope2x = scope2x,
                scope4x = scope4x,
                awm = awm,
                olhadinha = olhadinha
            ),
            idealDpi = idealDpi,
            fireButtonSizePercent = fireButtonPercent,
            dragTip = dragTip,
            deviceSummary = "${profile.vendorBrand.displayName} • ${profile.model} • ${profile.maxSupportedHz}Hz • Android ${profile.androidRelease}"
        )
    }
}
