package com.raylan.fangx.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.TypedValue
import android.view.View
import com.raylan.fangx.model.CrosshairConfig
import com.raylan.fangx.model.CrosshairShape
import kotlin.math.min

class CrosshairOverlayView(context: Context) : View(context) {

    private var config: CrosshairConfig = CrosshairConfig()

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = 0xAA000000.toInt()
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    fun updateConfig(newConfig: CrosshairConfig) {
        config = newConfig
        requestLayout()
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val sizePx = dpToPx(config.sizeDp + 16f).toInt().coerceAtLeast(48)
        setMeasuredDimension(sizePx, sizePx)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = min(cx, cy) - dpToPx(4f)
        if (radius <= 2f) return

        val baseColor = config.colorOption.hexColor.toInt()
        val alphaInt = (config.opacity.coerceIn(0.15f, 1.0f) * 255).toInt()
        val strokeWidth = dpToPx(2.2f)
        val gap = radius * 0.28f

        strokePaint.color = baseColor
        strokePaint.alpha = alphaInt
        strokePaint.strokeWidth = strokeWidth

        fillPaint.color = baseColor
        fillPaint.alpha = alphaInt

        shadowPaint.strokeWidth = strokeWidth + dpToPx(1.5f)
        shadowPaint.alpha = (alphaInt * 0.55f).toInt()

        when (config.shape) {
            CrosshairShape.DOT -> {
                val dotRadius = (radius * 0.22f).coerceAtLeast(dpToPx(2.5f))
                canvas.drawCircle(cx, cy, dotRadius + dpToPx(1f), shadowPaint)
                canvas.drawCircle(cx, cy, dotRadius, fillPaint)
            }
            CrosshairShape.CROSS -> {
                drawCrossArms(canvas, cx, cy, radius, gap, shadowPaint)
                drawCrossArms(canvas, cx, cy, radius, gap, strokePaint)
                canvas.drawCircle(cx, cy, dpToPx(1.8f), fillPaint)
            }
            CrosshairShape.CIRCLE_CROSS -> {
                val ringRadius = radius * 0.65f
                canvas.drawCircle(cx, cy, ringRadius, shadowPaint)
                drawCrossArms(canvas, cx, cy, radius, gap, shadowPaint)
                canvas.drawCircle(cx, cy, ringRadius, strokePaint)
                drawCrossArms(canvas, cx, cy, radius, gap, strokePaint)
                canvas.drawCircle(cx, cy, dpToPx(1.8f), fillPaint)
            }
            CrosshairShape.DIAMOND -> {
                drawDiamond(canvas, cx, cy, radius * 0.78f, shadowPaint)
                drawDiamond(canvas, cx, cy, radius * 0.78f, strokePaint)
                canvas.drawCircle(cx, cy, dpToPx(2.2f), fillPaint)
            }
            CrosshairShape.TACTICAL_X -> {
                val arm = radius * 0.75f
                val inner = radius * 0.22f
                drawDiagonalX(canvas, cx, cy, arm, inner, shadowPaint)
                drawDiagonalX(canvas, cx, cy, arm, inner, strokePaint)
                canvas.drawCircle(cx, cy, dpToPx(2f), fillPaint)
            }
        }
    }

    private fun drawCrossArms(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        radius: Float,
        gap: Float,
        paint: Paint
    ) {
        canvas.drawLine(cx - radius, cy, cx - gap, cy, paint)
        canvas.drawLine(cx + gap, cy, cx + radius, cy, paint)
        canvas.drawLine(cx, cy - radius, cx, cy - gap, paint)
        canvas.drawLine(cx, cy + gap, cx, cy + radius, paint)
    }

    private fun drawDiamond(canvas: Canvas, cx: Float, cy: Float, r: Float, paint: Paint) {
        canvas.drawLine(cx, cy - r, cx + r, cy, paint)
        canvas.drawLine(cx + r, cy, cx, cy + r, paint)
        canvas.drawLine(cx, cy + r, cx - r, cy, paint)
        canvas.drawLine(cx - r, cy, cx, cy - r, paint)
    }

    private fun drawDiagonalX(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        arm: Float,
        inner: Float,
        paint: Paint
    ) {
        canvas.drawLine(cx - arm, cy - arm, cx - inner, cy - inner, paint)
        canvas.drawLine(cx + inner, cy - inner, cx + arm, cy - arm, paint)
        canvas.drawLine(cx - arm, cy + arm, cx - inner, cy + inner, paint)
        canvas.drawLine(cx + inner, cy + inner, cx + arm, cy + arm, paint)
    }

    private fun dpToPx(dp: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp,
            resources.displayMetrics
        )
    }
}
