package com.raylan.fangx.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.GpsFixed
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.raylan.fangx.model.DeviceProfile
import com.raylan.fangx.model.FreeFireVersion
import com.raylan.fangx.model.LogStatus
import com.raylan.fangx.model.MainTab
import com.raylan.fangx.model.ShizukuStatus
import com.raylan.fangx.model.TerminalLogEntry
import com.raylan.fangx.ui.theme.FangxAmber
import com.raylan.fangx.ui.theme.FangxBg
import com.raylan.fangx.ui.theme.FangxBorder
import com.raylan.fangx.ui.theme.FangxCyan
import com.raylan.fangx.ui.theme.FangxGreen
import com.raylan.fangx.ui.theme.FangxRed
import com.raylan.fangx.ui.theme.FangxSurface
import com.raylan.fangx.ui.theme.FangxSurfaceElevated
import com.raylan.fangx.ui.theme.FangxTextMuted
import com.raylan.fangx.ui.theme.FangxTextPrimary
import com.raylan.fangx.ui.theme.FangxTextSecondary

@Composable
fun FangxTopHeader(
    deviceProfile: DeviceProfile,
    shizukuStatus: ShizukuStatus,
    onShizukuClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = FangxSurface,
        border = BorderStroke(1.dp, FangxBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                Brush.linearGradient(listOf(FangxCyan, FangxRed))
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.GpsFixed,
                            contentDescription = "Fangx Logo",
                            tint = FangxBg,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "FANGX",
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    fontWeight = FontWeight.Black
                                ),
                                color = FangxTextPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = FangxCyan.copy(alpha = 0.16f)
                            ) {
                                Text(
                                    text = "VIP",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = FangxCyan,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Text(
                            text = "${deviceProfile.vendorBrand.displayName} • ${deviceProfile.model} • ${deviceProfile.maxSupportedHz}Hz",
                            style = MaterialTheme.typography.labelSmall,
                            color = FangxTextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                val shizukuColor = when (shizukuStatus) {
                    ShizukuStatus.CONNECTED -> FangxGreen
                    ShizukuStatus.PERMISSION_REQUIRED -> FangxAmber
                    ShizukuStatus.NOT_RUNNING -> FangxRed
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = shizukuColor.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, shizukuColor.copy(alpha = 0.6f)),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .clickable { onShizukuClick() }
                        .testTag("shizuku_status_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(shizukuColor)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = shizukuStatus.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = shizukuColor
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FangxTabBar(
    selectedTab: MainTab,
    onSelectTab: (MainTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = FangxBg,
        border = BorderStroke(1.dp, FangxBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            MainTab.entries.forEach { tab ->
                val isSelected = selectedTab == tab
                val accent = when (tab) {
                    MainTab.MIRA -> FangxCyan
                    MainTab.FPS -> FangxRed
                    MainTab.SENSI -> FangxCyan
                    MainTab.SOBRE -> FangxGreen
                }
                val icon = when (tab) {
                    MainTab.MIRA -> Icons.Rounded.GpsFixed
                    MainTab.FPS -> Icons.Rounded.Speed
                    MainTab.SENSI -> Icons.Rounded.Tune
                    MainTab.SOBRE -> Icons.Rounded.Info
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) accent.copy(alpha = 0.16f) else FangxSurface,
                    border = BorderStroke(
                        width = 1.dp,
                        color = if (isSelected) accent else FangxBorder
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .clickable { onSelectTab(tab) }
                        .testTag("tab_${tab.name.lowercase()}")
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp)
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = tab.label,
                            tint = if (isSelected) accent else FangxTextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = tab.label,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (isSelected) accent else FangxTextSecondary,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FangxBottomInjectionBar(
    selectedFreeFire: FreeFireVersion,
    normalInstalled: Boolean,
    maxInstalled: Boolean,
    activeCommandCount: Int,
    isInjecting: Boolean,
    onSelectFreeFire: (FreeFireVersion) -> Unit,
    onInjectAndLaunch: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = FangxSurface,
        border = BorderStroke(1.dp, FangxBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .navigationBarsPadding()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                FreeFireVersionChip(
                    version = FreeFireVersion.NORMAL,
                    installed = normalInstalled,
                    selected = selectedFreeFire == FreeFireVersion.NORMAL,
                    onClick = { onSelectFreeFire(FreeFireVersion.NORMAL) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("selector_ff_normal")
                )
                FreeFireVersionChip(
                    version = FreeFireVersion.MAX,
                    installed = maxInstalled,
                    selected = selectedFreeFire == FreeFireVersion.MAX,
                    onClick = { onSelectFreeFire(FreeFireVersion.MAX) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("selector_ff_max")
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = onInjectAndLaunch,
                enabled = !isInjecting,
                colors = ButtonDefaults.buttonColors(
                    containerColor = FangxRed,
                    contentColor = FangxTextPrimary,
                    disabledContainerColor = FangxSurfaceElevated
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("inject_and_launch_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isInjecting) "INJETANDO..." else "INJETAR CÓDIGOS & ABRIR JOGO ($activeCommandCount)",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Black),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Desenvolvido por Raylan • Fangx Official",
                style = MaterialTheme.typography.labelSmall,
                color = FangxTextMuted,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .testTag("footer_credits")
            )
        }
    }
}

@Composable
private fun FreeFireVersionChip(
    version: FreeFireVersion,
    installed: Boolean,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = if (version == FreeFireVersion.NORMAL) FangxCyan else FangxRed
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (selected) accent.copy(alpha = 0.16f) else FangxSurfaceElevated,
        border = BorderStroke(1.dp, if (selected) accent else FangxBorder),
        modifier = modifier
            .minimumInteractiveComponentSize()
            .clickable { onClick() }
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = version.shortName,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (selected) accent else FangxTextPrimary
                )
                Text(
                    text = if (installed) "Instalado" else "Não detectado",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (installed) FangxGreen else FangxTextMuted,
                    maxLines = 1
                )
            }
            Box(
                modifier = Modifier
                    .size(9.dp)
                    .clip(CircleShape)
                    .background(if (selected) accent else FangxBorder)
            )
        }
    }
}

@Composable
fun InjectionTerminalDialog(
    isInjecting: Boolean,
    isComplete: Boolean,
    progress: Int,
    total: Int,
    logs: List<TerminalLogEntry>,
    onClose: () -> Unit
) {
    val listState = rememberLazyListState()
    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.lastIndex)
        }
    }

    Dialog(
        onDismissRequest = { if (!isInjecting) onClose() },
        properties = DialogProperties(
            dismissOnBackPress = !isInjecting,
            dismissOnClickOutside = !isInjecting,
            usePlatformDefaultWidth = false
        )
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = FangxBg,
            border = BorderStroke(1.5.dp, if (isComplete) FangxGreen else FangxCyan),
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 580.dp)
                .padding(16.dp)
                .testTag("injection_terminal_dialog")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isComplete) Icons.Rounded.CheckCircle else Icons.Rounded.Terminal,
                            contentDescription = "Terminal Fangx",
                            tint = if (isComplete) FangxGreen else FangxCyan,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = if (isInjecting) "INJEÇÃO CADENCIADA (40ms)" else "CONSOLE FINALIZADO",
                                style = MaterialTheme.typography.titleSmall,
                                color = if (isComplete) FangxGreen else FangxCyan
                            )
                            Text(
                                text = "Progresso: $progress / $total",
                                style = MaterialTheme.typography.labelSmall,
                                color = FangxTextSecondary,
                                modifier = Modifier.testTag("terminal_progress_text")
                            )
                        }
                    }

                    if (!isInjecting) {
                        IconButton(
                            onClick = onClose,
                            modifier = Modifier.testTag("close_terminal_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "Fechar console",
                                tint = FangxTextPrimary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                val fraction = if (total > 0) (progress.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f
                LinearProgressIndicator(
                    progress = { fraction },
                    color = if (isComplete) FangxGreen else FangxCyan,
                    trackColor = FangxSurfaceElevated,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                )

                Spacer(modifier = Modifier.height(12.dp))

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = FangxSurface,
                    border = BorderStroke(1.dp, FangxBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 240.dp, max = 360.dp)
                ) {
                    LazyColumn(
                        state = listState,
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(10.dp)
                    ) {
                        items(logs) { entry ->
                            val statusColor = when (entry.status) {
                                LogStatus.SUCCESS -> FangxGreen
                                LogStatus.INFO -> FangxCyan
                                LogStatus.WARN -> FangxAmber
                                LogStatus.ERROR -> FangxRed
                            }
                            Column {
                                Text(
                                    text = "[${entry.index}/${entry.total}] $ ${entry.command}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = statusColor
                                )
                                Text(
                                    text = "  -> ${entry.detail}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = FangxTextSecondary
                                )
                            }
                        }
                    }
                }

                if (!isInjecting) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onClose,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = FangxCyan,
                            contentColor = FangxBg
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Text(
                            text = "FECHAR TERMINAL",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }
    }
}
