package com.raylan.fangx

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.raylan.fangx.security.SecurityGuard
import com.raylan.fangx.security.SecurityState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class FangxRobolectricTest {

    @Test
    fun `verify app name and SecurityGuard integrity on official package`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Fangx", appName)
        assertEquals("com.raylan.fangx", context.packageName)

        val securityState = SecurityGuard.verifyIntegrity(context)
        assertTrue("Expected SecurityState.Verified, got $securityState", securityState is SecurityState.Verified)
    }
}
