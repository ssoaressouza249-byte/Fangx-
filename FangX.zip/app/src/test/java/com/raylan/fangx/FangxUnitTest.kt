package com.raylan.fangx

import com.raylan.fangx.data.CommandRepository
import com.raylan.fangx.data.MiraCommandBank
import com.raylan.fangx.data.PerformanceCommandBank
import com.raylan.fangx.engine.DeviceCompatibilityScanner
import com.raylan.fangx.model.DeviceProfile
import com.raylan.fangx.model.ModuleId
import com.raylan.fangx.model.NamespaceSupport
import com.raylan.fangx.model.VendorBrand
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FangxUnitTest {

    private fun sampleProfile(
        sdkInt: Int = 34,
        maxHz: Int = 120,
        highRefresh: Boolean = true
    ) = DeviceProfile(
        manufacturer = "Xiaomi",
        brandName = "POCO",
        vendorBrand = VendorBrand.XIAOMI,
        model = "POCO X6 Pro",
        sdkInt = sdkInt,
        androidRelease = "14",
        supportedRefreshRates = if (highRefresh) listOf(60, 90, 120) else listOf(60),
        maxSupportedHz = maxHz,
        selectedTargetHz = maxHz,
        currentDpi = 440,
        defaultDpi = 440,
        widthPx = 1220,
        heightPx = 2712,
        namespaceSupport = NamespaceSupport(
            settingsSystem = true,
            settingsSecure = true,
            settingsGlobal = true,
            deviceConfig = sdkInt >= 29,
            cmdPower = sdkInt >= 29,
            cmdDisplay = sdkInt >= 31,
            cmdThermal = sdkInt >= 29,
            cmdGame = sdkInt >= 31,
            highRefreshSupported = highRefresh
        ),
        freeFireNormalInstalled = true,
        freeFireMaxInstalled = false
    )

    @Test
    fun `mira command bank has exact 100 commands across 6 modules`() {
        val map = MiraCommandBank.buildCommands(sampleProfile())
        assertEquals(20, map[ModuleId.AIMBOT]?.size)
        assertEquals(18, map[ModuleId.AIMLOCK]?.size)
        assertEquals(16, map[ModuleId.NO_RECOIL]?.size)
        assertEquals(16, map[ModuleId.NO_RECOIL_2]?.size)
        assertEquals(15, map[ModuleId.AIMBOT_2X]?.size)
        assertEquals(15, map[ModuleId.HS_75]?.size)
        assertEquals(100, map.values.sumOf { it.size })
    }

    @Test
    fun `performance command bank has exact 100 commands across 5 modules`() {
        val map = PerformanceCommandBank.buildCommands(sampleProfile())
        assertEquals(20, map[ModuleId.BONECO_LENTO]?.size)
        assertEquals(15, map[ModuleId.FORCE_HZ]?.size)
        assertEquals(25, map[ModuleId.TURBO_BOOST]?.size)
        assertEquals(20, map[ModuleId.LOCK_FPS]?.size)
        assertEquals(20, map[ModuleId.LIGHT_UI]?.size)
        assertEquals(100, map.values.sumOf { it.size })
    }

    @Test
    fun `total command repository equals 200 commands and gates incompatible 60hz display`() {
        val profile60 = sampleProfile(sdkInt = 28, maxHz = 60, highRefresh = false)
        val modules = CommandRepository.buildModules(profile60)
        assertEquals(200, modules.sumOf { it.commands.size })

        val forceHz = modules.first { it.id == ModuleId.FORCE_HZ }
        assertFalse(forceHz.isCompatible)
        assertEquals("INCOMPATÍVEL COM ESTE APARELHO", forceHz.incompatibilityReason)

        val lockFps = modules.first { it.id == ModuleId.LOCK_FPS }
        assertFalse(lockFps.isCompatible)
    }

    @Test
    fun `perfect sensitivity generator keeps values strictly between 100 and 200`() {
        val recommendation = DeviceCompatibilityScanner.generatePerfectSensitivity(sampleProfile())
        val p = recommendation.profile
        assertTrue(p.geral in 100..200)
        assertTrue(p.redDot in 100..200)
        assertTrue(p.scope2x in 100..200)
        assertTrue(p.scope4x in 100..200)
        assertTrue(p.awm in 100..200)
        assertTrue(p.olhadinha in 100..200)
        assertTrue(recommendation.idealDpi in 400..800)
        assertTrue(recommendation.fireButtonSizePercent in 35..65)
    }
}
